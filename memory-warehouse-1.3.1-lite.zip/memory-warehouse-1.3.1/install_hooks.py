#!/usr/bin/env python
"""Install / uninstall Memory Warehouse hooks and the bundled skill.

Portable: paths are derived from this file and the current Python executable.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYTHON = Path(sys.executable)
MW = ROOT / "mw.py"
APP_HOME = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))

HOOK_NAMES = ["SessionStart", "Stop", "PreCompact", "SessionEnd"]
MARKER = "mw.py"
SKILL_NAME = "memory-warehouse"


def default_settings_path() -> Path:
    cherry = APP_HOME / "CherryStudio" / "Data" / "Agents" / ".claude" / "settings.json"
    if cherry.parent.exists():
        return cherry
    return Path.home() / ".claude" / "settings.json"


def default_skills_dir() -> Path:
    cherry = APP_HOME / "CherryStudio" / "Data" / "Skills"
    if cherry.exists():
        return cherry
    return Path.home() / ".claude" / "skills"


def command_for(hook: str) -> str:
    """SessionStart must write JSON to stdout; the others run windowless.

    pythonw.exe prevents the console window from flashing on every Stop /
    PreCompact / SessionEnd hook. Those hooks only write logs, so they do not
    need stdout.
    """
    executable = PYTHON
    if os.name == "nt" and hook != "session-start":
        candidate = PYTHON.with_name("pythonw.exe")
        if candidate.exists():
            executable = candidate
    return f'"{executable}" "{MW}" hook {hook}'


def is_ours(entry: dict) -> bool:
    for hook in entry.get("hooks") or []:
        command = hook.get("command") or ""
        lowered = command.lower()
        if MARKER in command and (
            "memory warehouse" in lowered or SKILL_NAME in lowered
        ):
            return True
    return False


def load_settings(settings_path: Path) -> dict:
    if settings_path.exists():
        try:
            return json.loads(settings_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def save_settings(settings_path: Path, data: dict) -> Path | None:
    backup = None
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    if settings_path.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = settings_path.with_name(f"{settings_path.name}.bak-{stamp}")
        shutil.copy2(settings_path, backup)
    settings_path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return backup


def install(settings_path: Path | None = None, dry_run: bool = False) -> int:
    settings_path = settings_path or default_settings_path()
    settings = load_settings(settings_path)
    hooks = settings.setdefault("hooks", {})
    mapping = {
        "SessionStart": "session-start",
        "Stop": "stop",
        "PreCompact": "pre-compact",
        "SessionEnd": "session-end",
    }
    for event, cli_name in mapping.items():
        entries = [entry for entry in (hooks.get(event) or []) if not is_ours(entry)]
        entry = {
            "hooks": [
                {
                    "type": "command",
                    "command": command_for(cli_name),
                    "timeout": 30,
                }
            ]
        }
        if event == "PreCompact":
            entry["matcher"] = "auto|manual"
        entries.append(entry)
        hooks[event] = entries
    if dry_run:
        print(f"[dry-run] would write hooks to {settings_path}")
        for event, cli_name in mapping.items():
            print(f"  {event}: {command_for(cli_name)}")
        return 0
    backup = save_settings(settings_path, settings)
    print(f"settings: {settings_path}")
    if backup:
        print(f"backup:   {backup}")
    print("installed hooks:")
    for event, cli_name in mapping.items():
        print(f"  {event}: {command_for(cli_name)}")
    return 0


def uninstall(settings_path: Path | None = None, dry_run: bool = False) -> int:
    settings_path = settings_path or default_settings_path()
    settings = load_settings(settings_path)
    hooks = settings.get("hooks") or {}
    for event in HOOK_NAMES:
        if event in hooks:
            hooks[event] = [entry for entry in hooks[event] if not is_ours(entry)]
            if not hooks[event]:
                del hooks[event]
    if dry_run:
        print(f"[dry-run] would remove Memory Warehouse hooks from {settings_path}")
        return 0
    backup = save_settings(settings_path, settings)
    print(f"removed Memory Warehouse hooks. backup: {backup}")
    return 0


def install_skill(
    skills_dir: Path | None = None, dry_run: bool = False
) -> int:
    skills_dir = skills_dir or default_skills_dir()
    template = ROOT / "skills" / SKILL_NAME / "SKILL.md"
    if not template.exists():
        print(f"skill template not found: {template}")
        return 1
    content = template.read_text(encoding="utf-8").replace(
        "{{MW_ROOT}}", str(ROOT).replace("\\", "/")
    )
    destination = skills_dir / SKILL_NAME / "SKILL.md"
    if dry_run:
        print(f"[dry-run] would install skill to {destination}")
        return 0
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content, encoding="utf-8")
    print(f"skill:    {destination}")
    return 0


def uninstall_skill(skills_dir: Path | None = None, dry_run: bool = False) -> int:
    skills_dir = skills_dir or default_skills_dir()
    target = skills_dir / SKILL_NAME
    if dry_run:
        print(f"[dry-run] would remove skill directory {target}")
        return 0
    if target.exists():
        shutil.rmtree(target)
        print(f"removed skill: {target}")
    else:
        print(f"skill not installed: {target}")
    return 0


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    parser = argparse.ArgumentParser(
        description="Install Memory Warehouse hooks and skill."
    )
    parser.add_argument("--settings", type=Path, help="path to settings.json")
    parser.add_argument("--skills-dir", type=Path, help="directory containing skills")
    parser.add_argument("--install-skill", action="store_true", help="also install the bundled skill")
    parser.add_argument("--uninstall", action="store_true", help="remove hooks")
    parser.add_argument("--uninstall-skill", action="store_true", help="remove the skill")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    if args.uninstall:
        return uninstall(args.settings, dry_run=args.dry_run)
    if args.uninstall_skill:
        return uninstall_skill(args.skills_dir, dry_run=args.dry_run)
    code = install(args.settings, dry_run=args.dry_run)
    if code == 0 and args.install_skill:
        code = install_skill(args.skills_dir, dry_run=args.dry_run)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
