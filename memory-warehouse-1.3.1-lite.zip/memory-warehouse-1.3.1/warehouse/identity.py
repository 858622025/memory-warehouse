"""Resolve the current Cherry Studio agent identity.

Cherry Studio launches each agent's Claude runtime with:
    --add-dir C:\\...\\Data\\Agents\\<agent-uuid>
That UUID is the only per-agent identifier available to hooks. The stdio MCP
server is launched by the app (not the agent runtime), so it cannot infer the
agent; its registration must pass `--agent-id <uuid>` explicitly.

Resolution order:
    1. explicit argument (CLI --agent / MCP --agent-id)
    2. MEMORY_WAREHOUSE_AGENT_ID
    3. CLAUDE_AGENT_ID (if the host sets it)
    4. CLAUDE_PID command line / ancestor process command lines (--add-dir)
    5. config.json -> agent.id
    6. None
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

AGENT_DIR_RE = re.compile(r"[\\/]Data[\\/]Agents[\\/]([0-9a-fA-F-]{36})", re.IGNORECASE)
UUID_RE = re.compile(r"^[0-9a-fA-F-]{36}$")
ADD_DIR_RE = re.compile(r"--add-dir\s+(?:\"([^\"]+)\"|(\S+))")
JOURNAL_AGENT_RE = re.compile(
    r"[\\/]Data[\\/]Agents[\\/]([^\\/]+)[\\/]memory[\\/]JOURNAL\.jsonl$",
    re.IGNORECASE,
)

_CACHE: dict[str, str | None] = {}
_PROCESS_CACHE: dict[int, tuple[int, str]] = {}
# Cross-process cache: hooks are short-lived processes, so an in-process cache
# is not enough. Keyed by Claude session id (preferred) or PID.
_CACHE_PATH = Path(__file__).resolve().parent.parent / "data" / "agent_cache.json"
_CACHE_TTL = 12 * 3600


def _hidden_kwargs(timeout: int = 3) -> dict:
    """Subprocess kwargs that never flash a console window on Windows."""
    kwargs: dict = {
        "stderr": subprocess.DEVNULL,
        "timeout": timeout,
        "text": True,
        "encoding": "utf-8",
        "errors": "ignore",
    }
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            info = subprocess.STARTUPINFO()
            info.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            info.wShowWindow = subprocess.SW_HIDE
            kwargs["startupinfo"] = info
        except Exception:
            pass
    return kwargs


def _cache_key() -> str | None:
    session = os.environ.get("CLAUDE_CODE_SESSION_ID")
    if session:
        return f"session:{session}"
    pid = os.environ.get("CLAUDE_PID")
    return f"pid:{pid}" if pid else None


def _read_cache(key: str | None) -> str | None:
    if not key:
        return None
    try:
        data = json.loads(_CACHE_PATH.read_text(encoding="utf-8"))
        item = data.get(key)
        if not item:
            return None
        if time.time() - float(item.get("ts") or 0) > _CACHE_TTL:
            return None
        return normalize_agent_id(item.get("agent_id"))
    except Exception:
        return None


def _write_cache(key: str | None, agent_id: str | None) -> None:
    if not key or not agent_id:
        return
    try:
        _CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        now = time.time()
        try:
            data = json.loads(_CACHE_PATH.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                data = {}
        except Exception:
            data = {}
        data[key] = {"agent_id": agent_id, "ts": now}
        data = {
            k: v
            for k, v in data.items()
            if isinstance(v, dict) and now - float(v.get("ts") or 0) <= _CACHE_TTL
        }
        if len(data) > 64:
            data = dict(
                sorted(
                    data.items(),
                    key=lambda kv: float(kv[1].get("ts") or 0),
                    reverse=True,
                )[:64]
            )
        tmp = _CACHE_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, _CACHE_PATH)
    except Exception:
        pass


def normalize_agent_id(value: str | os.PathLike | None) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    match = AGENT_DIR_RE.search(text)
    if match:
        return match.group(1)
    if UUID_RE.fullmatch(text):
        return text
    # A friendly name is allowed; keep it filesystem/URL safe.
    name = re.sub(r"[^A-Za-z0-9._-]+", "-", text).strip("-")
    return name or None


def agent_id_from_path(path: str | os.PathLike | None) -> str | None:
    """Extract an agent id from a path under Data/Agents/<id>/."""
    if not path:
        return None
    text = str(path)
    match = JOURNAL_AGENT_RE.search(text) or AGENT_DIR_RE.search(text)
    if match:
        return normalize_agent_id(match.group(1))
    return None


def agent_id_from_command_line(command_line: str | None) -> str | None:
    if not command_line:
        return None
    for match in ADD_DIR_RE.finditer(command_line):
        candidate = match.group(1) or match.group(2) or ""
        agent = normalize_agent_id(candidate)
        if agent and UUID_RE.fullmatch(agent):
            return agent
    return None


def _process_info_windows(pid: int) -> tuple[int, str]:
    if pid in _PROCESS_CACHE:
        return _PROCESS_CACHE[pid]
    info: tuple[int, str] = (0, "")
    # wmic is fast and available on most Windows installs.
    try:
        out = subprocess.check_output(
            [
                "wmic",
                "process",
                "where",
                f"processid={pid}",
                "get",
                "commandline,parentprocessid",
                "/value",
            ],
            **_hidden_kwargs(timeout=3),
        )
        command = ""
        parent = 0
        for line in out.splitlines():
            line = line.strip()
            if line.startswith("CommandLine="):
                command = line[len("CommandLine=") :]
            elif line.startswith("ParentProcessId="):
                try:
                    parent = int(line[len("ParentProcessId=") :])
                except ValueError:
                    parent = 0
        if command or parent:
            info = (parent, command)
    except Exception:
        pass
    if not info[0] and not info[1]:
        # PowerShell fallback (Windows 11 may not ship wmic).
        try:
            ps = (
                f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}';"
                "if($p){$p|Select-Object ParentProcessId,CommandLine|ConvertTo-Json -Compress}"
            )
            out = subprocess.check_output(
                ["powershell", "-NoProfile", "-Command", ps],
                **_hidden_kwargs(timeout=5),
            )
            data = json.loads(out.strip() or "{}")
            if isinstance(data, dict):
                info = (int(data.get("ParentProcessId") or 0), str(data.get("CommandLine") or ""))
        except Exception:
            pass
    _PROCESS_CACHE[pid] = info
    return info


def _process_info_unix(pid: int) -> tuple[int, str]:
    if pid in _PROCESS_CACHE:
        return _PROCESS_CACHE[pid]
    parent = 0
    command = ""
    try:
        stat = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8", errors="ignore")
        parts = stat.rsplit(")", 1)[1].split()
        parent = int(parts[1])
    except Exception:
        pass
    try:
        command = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ").decode(
            "utf-8", errors="ignore"
        )
    except Exception:
        pass
    _PROCESS_CACHE[pid] = (parent, command)
    return parent, command


def process_info(pid: int) -> tuple[int, str]:
    if pid <= 0:
        return 0, ""
    if sys.platform == "win32":
        return _process_info_windows(pid)
    return _process_info_unix(pid)


def _from_process_chain(start_pid: int, max_depth: int = 6) -> str | None:
    pid = start_pid
    seen: set[int] = set()
    for _ in range(max_depth):
        if pid <= 0 or pid in seen:
            break
        seen.add(pid)
        parent, command = process_info(pid)
        agent = agent_id_from_command_line(command)
        if agent:
            return agent
        pid = parent
    return None


def resolve_agent_id(
    explicit: str | os.PathLike | None = None,
    cfg: dict | None = None,
) -> str | None:
    agent = normalize_agent_id(explicit)
    if agent:
        return agent

    for key in ("MEMORY_WAREHOUSE_AGENT_ID", "CLAUDE_AGENT_ID", "CHERRY_AGENT_ID"):
        agent = normalize_agent_id(os.environ.get(key))
        if agent:
            return agent

    scope = _cache_key()
    cached = _read_cache(scope)
    if cached:
        return cached

    cache_key = "auto"
    if cache_key in _CACHE:
        return _CACHE[cache_key]

    claude_pid = os.environ.get("CLAUDE_PID")
    if claude_pid:
        try:
            agent = _from_process_chain(int(claude_pid))
        except ValueError:
            agent = None
        if agent:
            _CACHE[cache_key] = agent
            _write_cache(scope, agent)
            return agent

    agent = _from_process_chain(os.getppid())
    if not agent and cfg:
        agent = normalize_agent_id((cfg.get("agent") or {}).get("id"))
    _CACHE[cache_key] = agent
    _write_cache(scope, agent)
    return agent


def clear_cache() -> None:
    _CACHE.clear()
    _PROCESS_CACHE.clear()
