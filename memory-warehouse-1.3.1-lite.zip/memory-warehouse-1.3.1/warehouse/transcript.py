from __future__ import annotations

import json
from typing import Any

from .textutil import (
    cap_text,
    extract_refs,
    flatten_content,
    format_tool_use,
    json_compact,
    normalize_cwd,
    redact,
)

# Roles/kinds we intentionally ignore. These are UI/state records, not memory.
IGNORED_TYPES = {
    "attachment",
    "queue-operation",
    "last-prompt",
    "atis-latch",
    "mode",
    "cost-state",
}


def _bounded_input(value):
    """Keep tool input in meta only when it is small; the transcript holds the full copy."""
    rendered = json_compact(value)
    if len(rendered) <= 2000:
        return value
    return {"_preview": rendered[:2000], "_truncated": True}


def _make_event(
    *,
    cfg: dict,
    session_id: str | None,
    agent_id: str | None,
    turn_index: int,
    ts: str | None,
    role: str,
    kind: str,
    text: str,
    cwd: str | None,
    source_file: str,
    uuid: str | None,
    line_hash: str,
    block_index: int,
    is_sidechain: int,
    meta: dict[str, Any] | None = None,
) -> dict[str, Any]:
    caps = cfg.get("caps") or {}
    text = text or ""
    if cfg.get("redact", True):
        text = redact(text)
    text, truncated, original_len = cap_text(text, int(caps.get(kind, 4000)))
    meta = dict(meta or {})
    meta["truncated"] = bool(truncated)
    meta["original_len"] = original_len
    if truncated:
        meta["full_hint"] = "show"
    meta_str = json_compact(meta)
    if len(meta_str) > 12000:
        meta_str = json_compact(
            {
                "truncated_meta": True,
                "tool_name": meta.get("tool_name"),
                "files": meta.get("files"),
                "commands": meta.get("commands"),
                "urls": meta.get("urls"),
                "is_error": meta.get("is_error"),
                "truncated": bool(truncated),
                "original_len": original_len,
            }
        )
    ident = uuid or line_hash
    return {
        "event_key": f"{session_id or 'nosession'}:{ident}:{block_index}",
        "session_id": session_id,
        "agent_id": agent_id or "legacy",
        "turn_index": turn_index,
        "ts": ts,
        "role": role,
        "kind": kind,
        "content": text,
        "cwd": normalize_cwd(cwd),
        "source": "transcript",
        "source_uuid": uuid,
        "source_file": source_file,
        "block_index": block_index,
        "is_sidechain": int(is_sidechain),
        "pinned": 0,
        "tags": None,
        "meta": meta_str,
    }


def extract_events(rec: dict, ctx: dict) -> list[dict[str, Any]]:
    """Convert one transcript JSONL record into zero or more warehouse events.

    ctx carries mutable import state: turn_counter, session_id, source_file,
    line_hash and cfg.
    """
    rtype = rec.get("type")
    if rtype in IGNORED_TYPES:
        return []

    cfg = ctx["cfg"]
    source_file = ctx["source_file"]
    line_hash = ctx["line_hash"]
    is_sidechain = 1 if rec.get("isSidechain") else 0
    session_id = rec.get("sessionId") or ctx.get("session_id")
    if session_id:
        if ctx.get("session_id") and session_id != ctx["session_id"]:
            # A new session in the same file starts its own turn numbering.
            ctx["turn_counter"] = 0
        ctx["session_id"] = session_id

    explicit_agent = ctx.get("agent_id")
    if explicit_agent:
        agent_id = explicit_agent
    else:
        cache = ctx.setdefault("session_agent_cache", {})
        if session_id not in cache:
            lookup = ctx.get("lookup_agent")
            cache[session_id] = lookup(session_id) if lookup else None
        agent_id = cache.get(session_id) or "legacy"
    ctx["current_agent_id"] = agent_id
    ts = rec.get("timestamp")
    cwd = rec.get("cwd")
    uuid = rec.get("uuid")

    message = rec.get("message") if isinstance(rec.get("message"), dict) else {}
    role = message.get("role") or rtype
    content = message.get("content")

    events: list[dict[str, Any]] = []

    def add(kind: str, text: str, block_index: int, meta=None, ev_role=None):
        events.append(
            _make_event(
                cfg=cfg,
                session_id=session_id,
                agent_id=ctx.get("current_agent_id"),
                turn_index=ctx["turn_counter"],
                ts=ts,
                role=ev_role or role,
                kind=kind,
                text=text,
                cwd=cwd,
                source_file=source_file,
                uuid=uuid,
                line_hash=line_hash,
                block_index=block_index,
                is_sidechain=is_sidechain,
                meta=meta,
            )
        )

    if rtype == "assistant":
        if isinstance(content, str):
            add("text", content, 0, {"message_id": message.get("id")})
            return events
        blocks = content if isinstance(content, list) else []
        for index, block in enumerate(blocks):
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text":
                add("text", block.get("text", ""), index, {"message_id": message.get("id")})
            elif btype == "thinking":
                add(
                    "thinking",
                    block.get("thinking", ""),
                    index,
                    {"message_id": message.get("id")},
                )
            elif btype == "tool_use":
                name = block.get("name") or "tool"
                tool_input = block.get("input")
                refs = extract_refs(tool_input)
                meta = {
                    "tool_name": name,
                    "tool_use_id": block.get("id"),
                    "input": _bounded_input(tool_input),
                    "files": refs["files"],
                    "commands": refs["commands"],
                    "urls": refs["urls"],
                    "patterns": refs["patterns"],
                    "message_id": message.get("id"),
                }
                add("tool_use", format_tool_use(name, tool_input), index, meta)
            elif btype == "redacted_thinking":
                add("thinking", "[redacted thinking]", index)
            # ignore images in assistant output
        return events

    if rtype == "user":
        if rec.get("isCompactSummary"):
            meta = {
                "is_compact_summary": True,
                "prompt_id": rec.get("promptId"),
                "logical_parent_uuid": rec.get("logicalParentUuid"),
            }
            add("compaction_summary", flatten_content(content), 0, meta, ev_role="system")
            return events

        if isinstance(content, str):
            ctx["turn_counter"] += 1
            add("prompt", content, 0, {"prompt_id": rec.get("promptId")}, ev_role="user")
            return events

        if isinstance(content, list):
            counted_prompt = False
            for index, block in enumerate(content):
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                if btype == "text":
                    text = block.get("text", "")
                    if "system-reminder" in text and len(text) > 1500:
                        # Injected environment reminders are noise, not memory.
                        continue
                    if not counted_prompt:
                        ctx["turn_counter"] += 1
                        counted_prompt = True
                    add("prompt", text, index, {"prompt_id": rec.get("promptId")}, ev_role="user")
                elif btype == "tool_result":
                    text = flatten_content(block.get("content"))
                    meta = {
                        "tool_use_id": block.get("tool_use_id"),
                        "is_error": bool(block.get("is_error")),
                    }
                    add("tool_result", text, index, meta, ev_role="tool")
                elif btype == "image":
                    add("image", "[image]", index, ev_role="user")
                elif btype == "thinking":
                    add("thinking", block.get("thinking", ""), index)
            return events

        return events

    if rtype == "system":
        subtype = rec.get("subtype")
        if subtype == "compact_boundary":
            metadata = rec.get("compactMetadata") or {}
            preserved = metadata.get("preservedMessages") or {}
            preserved_uuids = list(dict.fromkeys(preserved.get("uuids") or []))
            all_uuids = list(dict.fromkeys(preserved.get("allUuids") or []))
            preserved_set = set(preserved_uuids)
            drops = [(u, 1 if u in preserved_set else 0) for u in all_uuids]
            meta = {
                "trigger": metadata.get("trigger"),
                "pre_tokens": metadata.get("preTokens"),
                "post_tokens": metadata.get("postTokens"),
                "cumulative_dropped_tokens": metadata.get("cumulativeDroppedTokens"),
                "duration_ms": metadata.get("durationMs"),
                "preserved_segment": metadata.get("preservedSegment"),
                "preserved_count": len(preserved_uuids),
                "context_count": len(all_uuids),
                "dropped_count": max(0, len(all_uuids) - len(preserved_uuids)),
            }
            text = (
                f"Conversation compacted ({metadata.get('trigger') or 'auto'}): "
                f"{metadata.get('preTokens')} → {metadata.get('postTokens')} tokens; "
                f"{meta['dropped_count']} messages summarized away."
            )
            event = _make_event(
                cfg=cfg,
                session_id=session_id,
                agent_id=ctx.get("current_agent_id"),
                turn_index=ctx["turn_counter"],
                ts=ts,
                role="system",
                kind="compact_boundary",
                text=text,
                cwd=cwd,
                source_file=source_file,
                uuid=uuid,
                line_hash=line_hash,
                block_index=0,
                is_sidechain=is_sidechain,
                meta=meta,
            )
            event["drops"] = drops
            events.append(event)
        elif subtype:
            add("system", rec.get("content") or json_compact(rec), 0, {"subtype": subtype}, ev_role="system")
        return events

    return events


def find_block_in_record(rec: dict, block_index: int):
    """Return the raw block (or string) that produced an event, for --full."""
    message = rec.get("message") if isinstance(rec.get("message"), dict) else {}
    content = message.get("content")
    if rec.get("isCompactSummary"):
        return content
    if isinstance(content, list):
        if 0 <= block_index < len(content):
            return content[block_index]
        return None
    if isinstance(content, str):
        return content
    return None


def full_text_from_block(block) -> str:
    if block is None:
        return ""
    if isinstance(block, str):
        return block
    if isinstance(block, dict):
        btype = block.get("type")
        if btype == "text":
            return block.get("text", "")
        if btype == "thinking":
            return block.get("thinking", "")
        if btype == "tool_result":
            return flatten_content(block.get("content"))
        if btype == "tool_use":
            return format_tool_use(block.get("name", "tool"), block.get("input"))
        return json_compact(block)
    return str(block)


def fetch_full_text(source_file: str | None, uuid: str | None, block_index: int) -> str | None:
    """Re-read the original transcript to recover an untruncated block."""
    if not source_file or not uuid:
        return None
    try:
        with open(source_file, "r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                if uuid not in line:
                    continue
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                if rec.get("uuid") != uuid:
                    continue
                return full_text_from_block(find_block_in_record(rec, block_index))
    except OSError:
        return None
    return None
