from __future__ import annotations

import json
import os
import sys
import traceback
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from .brief import build_brief
from .config import ROOT, load_config
from .db import connect
from .identity import normalize_agent_id, resolve_agent_id
from .importer import (
    lookup_session_agent,
    register_session_agent,
    sync_transcript,
)
from .textutil import (
    cap_text,
    clip,
    extract_must_keep,
    json_compact,
    normalize_cwd,
    now_iso,
    safe_json_loads,
    short_path,
)

LOG_PATH = ROOT / "logs" / "hook.log"
MAX_LOG_BYTES = 2 * 1024 * 1024


def log(message: str) -> None:
    try:
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        if LOG_PATH.exists() and LOG_PATH.stat().st_size > MAX_LOG_BYTES:
            backup = LOG_PATH.with_suffix(".log.1")
            try:
                if backup.exists():
                    backup.unlink()
                LOG_PATH.replace(backup)
            except OSError:
                pass
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_PATH, "a", encoding="utf-8") as handle:
            handle.write(f"{stamp} {message}\n")
    except Exception:
        pass


def read_hook_input() -> dict:
    raw = sys.stdin.read()
    if not raw or not raw.strip():
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _session_from_path(transcript_path: str | None) -> str | None:
    if not transcript_path:
        return None
    return Path(transcript_path).stem or None


def _sync_hook_transcript(
    conn, cfg: dict, data: dict, agent_id: str | None = None
) -> dict | None:
    path = data.get("transcript_path")
    if not path or not os.path.exists(path):
        return None
    try:
        return sync_transcript(
            conn, path, cfg, verbose=False, agent_id=agent_id
        )
    except Exception:
        log("sync failed:\n" + traceback.format_exc())
        return None


def create_checkpoint_from_tail(
    conn,
    cfg: dict,
    session_id: str,
    cwd: str | None,
    trigger: str = "auto",
    pre_tokens: int | None = None,
    custom_instructions: str | None = None,
    agent_id: str | None = None,
) -> int | None:
    """Snapshot the part of the conversation that is about to be summarized."""
    explicit_agent = normalize_agent_id(agent_id)
    if explicit_agent:
        register_session_agent(conn, session_id, explicit_agent)
    agent_id = (
        lookup_session_agent(conn, session_id) or explicit_agent or "legacy"
    )
    last_checkpoint = conn.execute(
        "SELECT COALESCE(MAX(id), 0) FROM events WHERE session_id = ? AND kind = 'checkpoint'",
        (session_id,),
    ).fetchone()[0]
    rows = conn.execute(
        """
        SELECT * FROM events
        WHERE session_id = ? AND id > ? AND is_sidechain = 0
          AND kind IN ('prompt', 'text', 'tool_use', 'tool_result', 'note', 'compaction_summary')
        ORDER BY id
        """,
        (session_id, last_checkpoint),
    ).fetchall()
    if not rows:
        rows = conn.execute(
            """
            SELECT * FROM events
            WHERE session_id = ? AND is_sidechain = 0
              AND kind IN ('prompt', 'text', 'tool_use', 'tool_result', 'note')
            ORDER BY id DESC LIMIT 300
            """,
            (session_id,),
        ).fetchall()
        rows = list(reversed(rows))
    if not rows:
        return None

    prompts: list[str] = []
    assistant_texts: list[str] = []
    tools: Counter[str] = Counter()
    files: list[str] = []
    commands: list[str] = []
    errors: list[str] = []
    texts: list[str] = []

    for row in rows:
        kind = row["kind"]
        content = row["content"] or ""
        meta = safe_json_loads(row["meta"]) or {}
        texts.append(content)
        if kind == "prompt":
            prompts.append(content)
        elif kind == "text":
            assistant_texts.append(content)
        elif kind == "tool_use":
            tools[meta.get("tool_name") or "tool"] += 1
            for path in meta.get("files") or []:
                if path not in files:
                    files.append(path)
            for command in meta.get("commands") or []:
                if command not in commands:
                    commands.append(command)
        elif kind == "tool_result" and meta.get("is_error"):
            errors.append(content)

    must_keep = extract_must_keep("\n".join(texts[-20:]), limit=32)
    parts = [f"上下文压缩前快照（{trigger}）"]
    if prompts:
        parts.append("用户请求：" + clip(prompts[-1], 500))
        if len(prompts) > 1:
            parts.append("前序请求：" + clip(" | ".join(prompts[-4:-1]), 500))
    if assistant_texts:
        parts.append("最后进展：" + clip(assistant_texts[-1], 700))
    if tools:
        parts.append("工具：" + ", ".join(f"{name}×{count}" for name, count in tools.most_common(8)))
    if files:
        parts.append("涉及文件：" + ", ".join(files[:10]))
    if commands:
        parts.append("执行命令：" + " | ".join(clip(command, 120) for command in commands[:6]))
    if errors:
        parts.append("报错：" + clip(errors[-1], 300))
    if must_keep:
        parts.append("关键标识：" + "; ".join(clip(item, 100) for item in must_keep[:12]))
    summary = "\n".join(parts)

    caps = cfg.get("caps") or {}
    text, truncated, original_len = cap_text(summary, int(caps.get("checkpoint", 8000)))
    meta = {
        "trigger": trigger,
        "pre_tokens": pre_tokens,
        "must_keep": must_keep,
        "event_start": rows[0]["id"],
        "event_end": rows[-1]["id"],
        "auto": True,
        "truncated": bool(truncated),
        "original_len": original_len,
    }
    if custom_instructions:
        meta["custom_instructions"] = clip(custom_instructions, 1000)
    stamp = now_iso()
    event_key = f"checkpoint:{session_id}:{stamp}"
    conn.execute(
        """
        INSERT OR IGNORE INTO events (
            event_key, session_id, agent_id, turn_index, ts, role, kind, content, cwd,
            source, source_uuid, source_file, block_index, is_sidechain,
            pinned, tags, meta, created_at
        ) VALUES (?, ?, ?, ?, ?, 'agent', 'checkpoint', ?, ?, 'hook', NULL, NULL, 0, 0, 0, ?, ?, ?)
        """,
        (
            event_key,
            session_id,
            agent_id,
            int(rows[-1]["turn_index"] or 0),
            stamp,
            text,
            normalize_cwd(cwd) or rows[-1]["cwd"],
            json_compact(["pre-compact", trigger]),
            json_compact(meta),
            stamp,
        ),
    )
    conn.commit()
    found = conn.execute("SELECT id FROM events WHERE event_key = ?", (event_key,)).fetchone()
    return int(found["id"]) if found else None


def hook_session_start(data: dict, cfg: dict, conn) -> None:
    cwd = data.get("cwd")
    source = data.get("source")
    agent_id = resolve_agent_id(cfg=cfg)
    text = build_brief(conn, cfg, cwd=cwd, source=source, agent_id=agent_id)
    log(f"session-start agent={agent_id or 'legacy'} cwd={cwd}")
    payload = {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": text,
        }
    }
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def hook_stop(data: dict, cfg: dict, conn) -> None:
    agent_id = resolve_agent_id(cfg=cfg)
    result = _sync_hook_transcript(conn, cfg, data, agent_id=agent_id)
    if result:
        log(
            f"stop sync agent={result.get('agent_id') or agent_id or 'legacy'} "
            f"session={result.get('session_id')} "
            f"imported={result.get('imported')} digests={result.get('digests')}"
        )
        session_id = result.get("session_id")
        if session_id:
            row = conn.execute(
                "SELECT MAX(turn_index) FROM events WHERE session_id = ?", (session_id,)
            ).fetchone()
            last_turn = int(row[0] or 0) if row else 0
            try:
                from .llm import spawn_auto_summary

                if spawn_auto_summary(cfg, session_id, last_turn):
                    log(f"stop auto-summary spawned session={session_id} turn={last_turn}")
            except Exception:
                log("auto-summary spawn failed:\n" + traceback.format_exc())
            try:
                from .vectors import spawn_auto_embed

                if spawn_auto_embed(cfg):
                    log("stop auto-embed spawned")
            except Exception:
                log("auto-embed spawn failed:\n" + traceback.format_exc())


def hook_pre_compact(data: dict, cfg: dict, conn) -> None:
    agent_id = resolve_agent_id(cfg=cfg)
    _sync_hook_transcript(conn, cfg, data, agent_id=agent_id)
    session_id = data.get("session_id") or _session_from_path(data.get("transcript_path"))
    if not session_id:
        return
    trigger = data.get("trigger") or "auto"
    checkpoint_id = create_checkpoint_from_tail(
        conn,
        cfg,
        session_id=session_id,
        cwd=data.get("cwd"),
        trigger=trigger,
        pre_tokens=data.get("pre_tokens") or data.get("preTokens"),
        custom_instructions=data.get("custom_instructions"),
        agent_id=agent_id,
    )
    log(
        f"pre-compact agent={agent_id or 'legacy'} session={session_id} "
        f"trigger={trigger} checkpoint={checkpoint_id}"
    )


def hook_session_end(data: dict, cfg: dict, conn) -> None:
    agent_id = resolve_agent_id(cfg=cfg)
    result = _sync_hook_transcript(conn, cfg, data, agent_id=agent_id)
    if result:
        log(
            f"session-end agent={result.get('agent_id') or agent_id or 'legacy'} "
            f"imported={result.get('imported')}"
        )


HOOKS = {
    "session-start": hook_session_start,
    "stop": hook_stop,
    "pre-compact": hook_pre_compact,
    "session-end": hook_session_end,
}


def run_hook(name: str) -> int:
    try:
        try:
            sys.stdout.reconfigure(encoding="utf-8")
            sys.stderr.reconfigure(encoding="utf-8")
        except Exception:
            pass
        cfg = load_config()
        data = read_hook_input()
        handler = HOOKS.get(name)
        if handler is None:
            log(f"unknown hook: {name}")
            return 0
        conn = connect(cfg["db_path"])
        try:
            handler(data, cfg, conn)
        finally:
            conn.close()
    except Exception:
        log(f"hook {name} failed:\n" + traceback.format_exc())
    # Hooks must never block the agent.
    return 0
