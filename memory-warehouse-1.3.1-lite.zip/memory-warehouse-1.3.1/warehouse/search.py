from __future__ import annotations

import math
import re
import sqlite3
from datetime import datetime, timezone

from .textutil import clip, normalize_cwd, parse_iso, project_label, short_path
from .transcript import fetch_full_text

TERM_RE = re.compile(r"[\w㐀-䶿一-鿿]+", re.UNICODE)


def _terms(query: str) -> list[str]:
    terms: list[str] = []
    seen: set[str] = set()
    for term in TERM_RE.findall(query or ""):
        term = term.strip("_")
        if not term:
            continue
        key = term.lower()
        if key in seen:
            continue
        seen.add(key)
        terms.append(term)
    return terms


def _quote(term: str) -> str:
    return '"' + term.replace('"', '""') + '"'


def _build_match(query: str, op: str = "AND") -> str | None:
    terms = [term for term in _terms(query) if len(term) >= 3]
    if not terms:
        return None
    return f" {op} ".join(_quote(term) for term in terms)


def _fallback_match(query: str) -> str | None:
    """For CJK, a long query rarely appears verbatim; use overlapping trigrams."""
    parts: list[str] = []
    seen: set[str] = set()
    for term in _terms(query):
        candidates: list[str] = []
        if len(term) >= 3 and any("㐀" <= ch <= "鿿" for ch in term):
            candidates = [term[i : i + 3] for i in range(len(term) - 2)]
        elif len(term) >= 3:
            candidates = [term]
        for candidate in candidates:
            key = candidate.lower()
            if key not in seen:
                seen.add(key)
                parts.append(candidate)
        if len(parts) >= 24:
            break
    if not parts:
        return None
    return " OR ".join(_quote(part) for part in parts[:24])


def _like_pattern(term: str) -> str:
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def _recency_boost(ts: str | None) -> float:
    dt = parse_iso(ts)
    if not dt:
        return 1.0
    days = max(0.0, (datetime.now(timezone.utc) - dt).total_seconds() / 86400.0)
    return 1.0 + 0.25 * math.exp(-days / 45.0)


def _build_filters(
    cwd: str | None,
    session: str | None,
    kinds: list[str] | None,
    since: str | None,
    until: str | None,
    include_sidechain: bool,
    alias: str,
    kind_exclude: str | None = None,
    agent_id: str | None = None,
) -> tuple[str, list]:
    clauses: list[str] = []
    params: list = []
    cwd = normalize_cwd(cwd)
    if agent_id != "*":
        target = agent_id or "legacy"
        if target == "legacy":
            clauses.append(
                f"({alias}.agent_id = ? OR {alias}.agent_id IS NULL)"
            )
        else:
            clauses.append(f"{alias}.agent_id = ?")
        params.append(target)
    if cwd:
        clauses.append(f"{alias}.cwd = ? COLLATE NOCASE")
        params.append(cwd)
    if session:
        clauses.append(f"{alias}.session_id LIKE ?")
        params.append(f"{session}%")
    usable = [k for k in (kinds or []) if k != kind_exclude] if kind_exclude else list(kinds or [])
    if kinds:
        if usable:
            clauses.append(f"{alias}.kind IN ({','.join('?' for _ in usable)})")
            params.extend(usable)
        elif kind_exclude:
            clauses.append(f"{alias}.kind != ?")
            params.append(kind_exclude)
    if since:
        clauses.append(f"{alias}.ts >= ?")
        params.append(since)
    if until:
        clauses.append(f"{alias}.ts <= ?")
        params.append(until)
    if not include_sidechain:
        clauses.append(f"{alias}.is_sidechain = 0")
    return (" AND " + " AND ".join(clauses) if clauses else ""), params


def _event_rows(conn, match: str, filters: str, params: list, limit: int):
    sql = f"""
        SELECT e.id AS event_id, e.ts, e.role, e.kind, e.content, e.cwd,
               e.session_id, e.agent_id, e.turn_index, e.meta,
               snippet(events_fts, 0, '«', '»', ' … ', 24) AS snip,
               bm25(events_fts) AS bm
        FROM events_fts
        JOIN events e ON e.id = events_fts.rowid
        WHERE events_fts MATCH ? {filters}
        ORDER BY bm ASC
        LIMIT ?
    """
    return conn.execute(sql, [match, *params, limit]).fetchall()


def _simple_filters(
    cwd, session, since, until, alias: str = "d", agent_id: str | None = None
) -> tuple[str, list]:
    clauses: list[str] = []
    params: list = []
    cwd = normalize_cwd(cwd)
    if agent_id != "*":
        target = agent_id or "legacy"
        if target == "legacy":
            clauses.append(
                f"({alias}.agent_id = ? OR {alias}.agent_id IS NULL)"
            )
        else:
            clauses.append(f"{alias}.agent_id = ?")
        params.append(target)
    if cwd:
        clauses.append(f"{alias}.cwd = ? COLLATE NOCASE")
        params.append(cwd)
    if session:
        clauses.append(f"{alias}.session_id LIKE ?")
        params.append(f"{session}%")
    # The digests table stores started_at/ended_at instead of ts.
    if since:
        clauses.append(f"COALESCE({alias}.ended_at, {alias}.started_at) >= ?")
        params.append(since)
    if until:
        clauses.append(f"COALESCE({alias}.ended_at, {alias}.started_at) <= ?")
        params.append(until)
    return (" AND " + " AND ".join(clauses) if clauses else ""), params


def _digest_rows(
    conn, match: str, cwd, session, since, until, limit: int, agent_id=None
):
    filters, params = _simple_filters(
        cwd, session, since, until, alias="d", agent_id=agent_id
    )
    sql = f"""
        SELECT d.id AS digest_id, d.session_id, d.agent_id, d.turn_index, d.cwd,
               d.started_at, d.ended_at, d.summary,
               snippet(digests_fts, 0, '«', '»', ' … ', 24) AS snip,
               bm25(digests_fts) AS bm
        FROM digests_fts
        JOIN digests d ON d.id = digests_fts.rowid
        WHERE digests_fts MATCH ? {filters}
        ORDER BY bm ASC
        LIMIT ?
    """
    return conn.execute(sql, [match, *params, limit]).fetchall()


def _event_like_rows(conn, query: str, filters: str, params: list, limit: int):
    terms = _terms(query)[:4]
    if not terms:
        return []
    clauses = " AND ".join("e.content LIKE ? ESCAPE '\\'" for _ in terms)
    sql = f"""
        SELECT e.id AS event_id, e.ts, e.role, e.kind, e.content, e.cwd,
               e.session_id, e.agent_id, e.turn_index, e.meta,
               NULL AS snip, -1.0 AS bm
        FROM events e
        WHERE {clauses} {filters}
        ORDER BY e.id DESC
        LIMIT ?
    """
    try:
        return conn.execute(sql, [*(_like_pattern(t) for t in terms), *params, limit]).fetchall()
    except sqlite3.OperationalError:
        return []


def _digest_like_rows(
    conn, query: str, cwd, session, since, until, limit: int, agent_id=None
):
    terms = _terms(query)[:4]
    if not terms:
        return []
    filters, params = _simple_filters(
        cwd, session, since, until, alias="d", agent_id=agent_id
    )
    clauses = " AND ".join("d.summary LIKE ? ESCAPE '\\'" for _ in terms)
    sql = f"""
        SELECT d.id AS digest_id, d.session_id, d.agent_id, d.turn_index, d.cwd,
               d.started_at, d.ended_at, d.summary,
               NULL AS snip, -1.0 AS bm
        FROM digests d
        WHERE {clauses} {filters}
        ORDER BY d.id DESC
        LIMIT ?
    """
    try:
        return conn.execute(sql, [*(_like_pattern(t) for t in terms), *params, limit]).fetchall()
    except sqlite3.OperationalError:
        return []


def _merge(event_rows, digest_rows, limit: int) -> list[dict]:
    results: list[dict] = []
    for row in event_rows:
        content = row["content"] or ""
        snippet = row["snip"] or clip(content, 260)
        results.append(
            {
                "type": "event",
                "id": row["event_id"],
                "ts": row["ts"],
                "role": row["role"],
                "kind": row["kind"],
                "content": content,
                "snippet": snippet,
                "cwd": row["cwd"],
                "session_id": row["session_id"],
                "agent_id": row["agent_id"],
                "turn_index": row["turn_index"],
                "score": max(0.0, -float(row["bm"] or 0.0)) * _recency_boost(row["ts"]),
            }
        )
    for row in digest_rows:
        summary = row["summary"] or ""
        snippet = row["snip"] or clip(summary, 300)
        results.append(
            {
                "type": "digest",
                "id": row["digest_id"],
                "ts": row["ended_at"] or row["started_at"],
                "role": "agent",
                "kind": "digest",
                "content": summary,
                "snippet": snippet,
                "cwd": row["cwd"],
                "session_id": row["session_id"],
                "agent_id": row["agent_id"],
                "turn_index": row["turn_index"],
                "score": max(0.0, -float(row["bm"] or 0.0))
                * _recency_boost(row["ended_at"] or row["started_at"])
                * 1.6,
            }
        )
    results.sort(key=lambda item: item["score"], reverse=True)
    return results[:limit]


def _bm25_results(
    conn: sqlite3.Connection,
    query: str,
    *,
    limit: int,
    cwd: str | None,
    session: str | None,
    kinds: list[str] | None,
    since: str | None,
    until: str | None,
    include_sidechain: bool,
    any_terms: bool,
    agent_id: str | None = None,
) -> list[dict]:
    want_events = not kinds or any(kind != "digest" for kind in kinds)
    want_digests = not kinds or "digest" in kinds
    filters, params = _build_filters(
        cwd,
        session,
        kinds,
        since,
        until,
        include_sidechain,
        "e",
        agent_id=agent_id,
    )
    attempts: list[str | None] = [_build_match(query, "OR" if any_terms else "AND")]
    fallback = _fallback_match(query)
    if fallback and fallback not in attempts:
        attempts.append(fallback)

    for match in attempts:
        if not match:
            continue
        try:
            event_rows = _event_rows(conn, match, filters, params, limit) if want_events else []
            digest_rows = (
                _digest_rows(
                    conn, match, cwd, session, since, until, limit, agent_id=agent_id
                )
                if want_digests
                else []
            )
        except sqlite3.OperationalError:
            continue
        merged = _merge(event_rows, digest_rows, limit)
        if merged:
            return merged

    event_rows = _event_like_rows(conn, query, filters, params, limit) if want_events else []
    digest_rows = (
        _digest_like_rows(
            conn, query, cwd, session, since, until, limit, agent_id=agent_id
        )
        if want_digests
        else []
    )
    return _merge(event_rows, digest_rows, limit)


def _rrf_fuse(bm25: list[dict], semantic: list[dict], limit: int, k: int = 60) -> list[dict]:
    """Reciprocal Rank Fusion of lexical and semantic candidates."""
    fused: dict[tuple[str, int], dict] = {}
    for rank, item in enumerate(bm25, 1):
        key = (item["type"], int(item["id"]))
        entry = fused.setdefault(
            key, {"item": item, "score": 0.0, "bm_rank": None, "vec_rank": None}
        )
        entry["score"] += 1.0 / (k + rank)
        entry["bm_rank"] = rank
    for rank, item in enumerate(semantic, 1):
        key = (item["type"], int(item["id"]))
        entry = fused.get(key)
        if entry is None:
            entry = {"item": item, "score": 0.0, "bm_rank": None, "vec_rank": None}
            fused[key] = entry
        # Equal-weight RRF. A higher vector weight lets a semantic rank-3
        # candidate beat an exact lexical rank-1 match, which is wrong.
        entry["score"] += 1.0 / (k + rank)
        entry["vec_rank"] = rank
        entry["vec_score"] = item.get("score")
        if not entry["item"].get("snippet") and item.get("snippet"):
            entry["item"]["snippet"] = item["snippet"]

    for entry in fused.values():
        item = entry["item"]
        item["score"] = entry["score"] * _recency_boost(item.get("ts"))
        item["bm25_rank"] = entry["bm_rank"]
        item["vec_rank"] = entry["vec_rank"]
        item["vector_score"] = entry.get("vec_score")
        if entry["bm_rank"] and entry["vec_rank"]:
            item["source"] = "hybrid"
        elif entry["bm_rank"]:
            item["source"] = "bm25"
        else:
            item["source"] = "vector"
    ranked = sorted(fused.values(), key=lambda entry: entry["score"], reverse=True)
    return [entry["item"] for entry in ranked[:limit]]


def search(
    conn: sqlite3.Connection,
    query: str,
    *,
    cfg: dict | None = None,
    semantic: bool | None = None,
    limit: int = 10,
    cwd: str | None = None,
    session: str | None = None,
    kinds: list[str] | None = None,
    since: str | None = None,
    until: str | None = None,
    include_sidechain: bool = False,
    any_terms: bool = False,
    agent_id: str | None = None,
) -> list[dict]:
    if not (query or "").strip():
        return []
    # Fuse over a wider candidate pool; a narrow pool makes RRF ignore the
    # lexical match that disagrees with the vector ranking.
    candidate_limit = max(limit * 8, 60)
    bm25 = _bm25_results(
        conn,
        query,
        limit=candidate_limit,
        cwd=cwd,
        session=session,
        kinds=kinds,
        since=since,
        until=until,
        include_sidechain=include_sidechain,
        any_terms=any_terms,
        agent_id=agent_id,
    )

    use_semantic = semantic
    if use_semantic is None:
        use_semantic = bool((cfg or {}).get("embeddings", {}).get("auto", True))
    if not use_semantic or cfg is None:
        return bm25[:limit]

    try:
        from . import vectors as vectors_mod

        if not vectors_mod.available(conn, cfg):
            return bm25[:limit]
        sem = vectors_mod.semantic_search(
            conn,
            cfg,
            query,
            limit=candidate_limit,
            cwd=cwd,
            session=session,
            kinds=kinds,
            since=since,
            until=until,
            agent_id=agent_id,
        )
    except Exception:
        return bm25[:limit]

    if not sem:
        return bm25[:limit]
    if not bm25:
        return sem[:limit]
    return _rrf_fuse(bm25, sem, limit)


def format_results(results: list[dict], show_scores: bool = False) -> str:
    if not results:
        return "没有找到匹配的记忆。可以换关键词，或扩大时间范围（--since 90d）。"
    lines: list[str] = []
    for index, item in enumerate(results, 1):
        ts = (item.get("ts") or "")[:16].replace("T", " ")
        project = project_label(item.get("cwd"))
        session = (item.get("session_id") or "?")[:8]
        turn = item.get("turn_index")
        label = "摘要" if item.get("type") == "digest" else (item.get("kind") or "?")
        header = f"[{index}] {ts} · {project} · {session}#{turn} · {label}"
        if show_scores:
            source = item.get("source") or "bm25"
            bm_rank = item.get("bm25_rank")
            vec_rank = item.get("vec_rank")
            header += f" · {item['score']:.3f} · {source}"
            if bm_rank:
                header += f" (bm#{bm_rank})"
            if vec_rank:
                header += f" (vec#{vec_rank}"
                if item.get("vector_score") is not None:
                    header += f" v={item['vector_score']:.2f}"
                header += ")"
        snippet = " ".join((item.get("snippet") or "").split())
        # Avoid nested markers when a previous recall result was itself indexed.
        snippet = snippet.replace("««", "«").replace("»»", "»")
        lines.append(header)
        lines.append(f"    {snippet}")
        lines.append(f"    id={item['id']}  ({item.get('type')})")
        lines.append("")
    return "\n".join(lines).rstrip()


def show_event(
    conn: sqlite3.Connection, event_id: int, agent_id: str | None = None
) -> dict:
    row = conn.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    if not row:
        raise KeyError(f"event {event_id} not found")
    if agent_id and agent_id != "*":
        row_agent = row["agent_id"] or "legacy"
        if row_agent != agent_id:
            raise KeyError(f"event {event_id} not found for agent {agent_id}")
    full = None
    if row["source"] == "transcript":
        full = fetch_full_text(
            row["source_file"], row["source_uuid"], int(row["block_index"] or 0)
        )
    return {
        "id": row["id"],
        "ts": row["ts"],
        "role": row["role"],
        "kind": row["kind"],
        "cwd": row["cwd"],
        "session_id": row["session_id"],
        "agent_id": row["agent_id"],
        "turn_index": row["turn_index"],
        "source_file": row["source_file"],
        "content": row["content"],
        "full_content": full if full is not None else row["content"],
        "meta": row["meta"],
    }


def timeline(
    conn: sqlite3.Connection,
    *,
    cwd: str | None = None,
    session: str | None = None,
    limit: int = 30,
    agent_id: str | None = None,
) -> list[dict]:
    filters, params = _build_filters(
        cwd, session, None, None, None, True, "d", agent_id=agent_id
    )
    sql = f"""
        SELECT d.* FROM digests d
        WHERE 1=1 {filters}
        ORDER BY d.ended_at DESC
        LIMIT ?
    """
    rows = conn.execute(sql, [*params, limit]).fetchall()
    return [dict(row) for row in rows]


def lost_events(
    conn: sqlite3.Connection,
    session: str,
    limit: int = 100,
    agent_id: str | None = None,
) -> list[dict]:
    """Events whose context messages were summarized away by a compaction."""
    if agent_id == "*":
        agent_clause = ""
    elif (agent_id or "legacy") == "legacy":
        agent_clause = "AND (e.agent_id = ? OR e.agent_id IS NULL)"
    else:
        agent_clause = "AND e.agent_id = ?"
    sql = f"""
        SELECT DISTINCT e.id, e.ts, e.role, e.kind, e.content, e.session_id,
                        e.agent_id, e.turn_index, e.cwd
        FROM events e
        JOIN compaction_drops d ON d.uuid = e.source_uuid
        JOIN events cb ON cb.id = d.event_id
        WHERE cb.session_id LIKE ? AND d.preserved = 0 {agent_clause}
        ORDER BY e.id DESC
        LIMIT ?
    """
    params: list = [f"{session}%"]
    if agent_id != "*":
        params.append(agent_id or "legacy")
    params.append(limit)
    rows = conn.execute(sql, params).fetchall()
    return [dict(row) for row in rows]


def recent_notes(
    conn: sqlite3.Connection,
    limit: int = 10,
    pinned_only: bool = False,
    agent_id: str | None = None,
) -> list[dict]:
    clause = "AND pinned = 1" if pinned_only else ""
    if agent_id == "*":
        agent_clause = ""
    elif (agent_id or "legacy") == "legacy":
        agent_clause = "AND (agent_id = ? OR agent_id IS NULL)"
    else:
        agent_clause = "AND agent_id = ?"
    params: list = []
    if agent_id != "*":
        params.append(agent_id or "legacy")
    params.append(limit)
    rows = conn.execute(
        f"""
        SELECT id, ts, cwd, content, pinned, tags, session_id, agent_id
        FROM events
        WHERE kind IN ('note', 'checkpoint') {clause} {agent_clause}
        ORDER BY id DESC LIMIT ?
        """,
        params,
    ).fetchall()
    return [dict(row) for row in rows]
