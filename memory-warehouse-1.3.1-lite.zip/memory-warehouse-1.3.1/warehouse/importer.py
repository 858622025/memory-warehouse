from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from pathlib import Path
from typing import Iterable

from .digest import rebuild_digest
from .identity import normalize_agent_id
from .textutil import now_iso
from .transcript import extract_events

INSERT_EVENT_SQL = """
INSERT OR IGNORE INTO events (
    event_key, session_id, agent_id, turn_index, ts, role, kind, content, cwd,
    source, source_uuid, source_file, block_index, is_sidechain,
    pinned, tags, meta, created_at
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
"""


def lookup_session_agent(conn: sqlite3.Connection, session_id: str | None) -> str | None:
    if not session_id:
        return None
    row = conn.execute(
        "SELECT agent_id FROM session_agents WHERE session_id = ?", (session_id,)
    ).fetchone()
    return row["agent_id"] if row else None


def register_session_agent(
    conn: sqlite3.Connection,
    session_id: str | None,
    agent_id: str | None,
    force: bool = False,
) -> bool:
    """Map a session to an agent and backfill legacy/unknown events.

    Returns True when the mapping was applied, False when an existing mapping
    for a different agent was kept.
    """
    agent_id = normalize_agent_id(agent_id)
    if not session_id or not agent_id:
        return False
    existing = conn.execute(
        "SELECT agent_id FROM session_agents WHERE session_id = ?", (session_id,)
    ).fetchone()
    if existing and existing["agent_id"] != agent_id and not force:
        return False
    conn.execute(
        """
        INSERT INTO session_agents(session_id, agent_id, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(session_id) DO UPDATE SET
            agent_id=excluded.agent_id, updated_at=excluded.updated_at
        """,
        (session_id, agent_id, now_iso()),
    )
    clause = "" if force else "AND (agent_id IS NULL OR agent_id = 'legacy')"
    conn.execute(
        f"UPDATE events SET agent_id = ? WHERE session_id = ? {clause}",
        (agent_id, session_id),
    )
    conn.execute(
        f"UPDATE digests SET agent_id = ? WHERE session_id = ? {clause}",
        (agent_id, session_id),
    )
    conn.execute(
        f"UPDATE import_state SET agent_id = ? WHERE session_id = ? {clause}",
        (agent_id, session_id),
    )
    return True

BATCH_SIZE = 400


def discover_transcripts(roots: Iterable[str], since_days: float | None = None) -> list[str]:
    import time

    cutoff = None
    if since_days is not None:
        cutoff = time.time() - since_days * 86400
    found: list[str] = []
    seen: set[str] = set()
    for root in roots:
        base = Path(root)
        if not base.exists():
            continue
        for path in base.rglob("*.jsonl"):
            try:
                real = str(path.resolve())
                if real in seen:
                    continue
                if cutoff is not None and path.stat().st_mtime < cutoff:
                    continue
                seen.add(real)
                found.append(real)
            except OSError:
                continue
    found.sort(key=lambda p: _safe_mtime(p))
    return found


def _safe_mtime(path: str) -> float:
    try:
        return os.stat(path).st_mtime
    except OSError:
        return 0.0


def _fingerprint(path: str, offset: int) -> str | None:
    """Hash the first 4KB + the 4KB before the import offset.

    Append-only transcripts keep this stable; a rewrite (including one that
    grows the file) changes it. Returns None when the file is shorter than
    the offset, which is also a rewrite.
    """
    if offset <= 0:
        return ""
    try:
        size = os.path.getsize(path)
        if size < offset:
            return None
        with open(path, "rb") as handle:
            # Only hash bytes that existed at the old offset. Reading the
            # whole first 4KB would make every small-file append look like a
            # rewrite.
            head = handle.read(min(4096, offset))
            start = max(0, offset - 4096)
            handle.seek(start)
            tail = handle.read(offset - start)
    except OSError:
        return None
    digest = hashlib.sha1()
    digest.update(str(offset).encode("ascii"))
    digest.update(b"\0")
    digest.update(head)
    digest.update(b"\0")
    digest.update(tail)
    return digest.hexdigest()


def _insert_events(conn: sqlite3.Connection, events: list[dict]) -> int:
    if not events:
        return 0
    before = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    created = now_iso()
    rows = [
        (
            ev["event_key"],
            ev.get("session_id"),
            ev.get("agent_id") or "legacy",
            ev.get("turn_index", 0),
            ev.get("ts"),
            ev.get("role"),
            ev.get("kind"),
            ev.get("content") or "",
            ev.get("cwd"),
            ev.get("source"),
            ev.get("source_uuid"),
            ev.get("source_file"),
            ev.get("block_index"),
            ev.get("is_sidechain", 0),
            ev.get("pinned", 0),
            ev.get("tags"),
            ev.get("meta"),
            created,
        )
        for ev in events
    ]
    conn.executemany(INSERT_EVENT_SQL, rows)
    after = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    return after - before


def sync_transcript(
    conn: sqlite3.Connection,
    path: str,
    cfg: dict,
    verbose: bool = False,
    agent_id: str | None = None,
) -> dict:
    """Incrementally import one append-only transcript JSONL file."""
    agent_id = normalize_agent_id(agent_id)
    path = os.path.abspath(path)
    try:
        stat = os.stat(path)
    except OSError as exc:
        return {"path": path, "error": str(exc), "imported": 0}

    row = conn.execute("SELECT * FROM import_state WHERE path = ?", (path,)).fetchone()

    if (
        row
        and row["fingerprint"]
        and int(row["size"]) == stat.st_size
        and abs(float(row["mtime"]) - stat.st_mtime) < 1e-6
    ):
        state_agent = (
            lookup_session_agent(conn, row["session_id"])
            or row["agent_id"]
            or "legacy"
        )
        return {
            "path": path,
            "session_id": row["session_id"],
            "agent_id": state_agent,
            "imported": 0,
            "extracted": 0,
            "parsed_lines": 0,
            "skipped_lines": 0,
            "digests": 0,
            "offset": int(row["offset"]),
            "bytes": stat.st_size,
            "rewritten": False,
            "skipped": "unchanged",
        }

    offset = int(row["offset"]) if row else 0
    old_offset = offset
    turn_counter = int(row["turn_counter"]) if row else 0
    line_no = int(row["line_no"]) if row else 0
    session_id = row["session_id"] if row else None
    # Existing ownership wins: an MCP server / hook must not accidentally
    # re-tag a transcript that already belongs to another agent.
    if agent_id and session_id:
        mapped = lookup_session_agent(conn, session_id)
        if mapped and mapped != agent_id:
            agent_id = mapped
    rewritten = False

    if offset > 0:
        current_fingerprint = _fingerprint(path, offset)
        stored_fingerprint = row["fingerprint"] if row else None
        if current_fingerprint is None or (
            stored_fingerprint and current_fingerprint != stored_fingerprint
        ):
            # The transcript was compacted/rewritten. Start over; event_key
            # dedupe keeps the events we already captured. Keep the turn
            # counter so post-compaction turns don't overwrite old digests;
            # extract_events resets it only if the session id changes.
            rewritten = True
            offset = 0
            line_no = 0

    if offset > stat.st_size:
        # File was truncated or replaced: start over.
        rewritten = True
        offset = 0
        line_no = 0

    ctx = {
        "cfg": cfg,
        "session_id": session_id,
        "agent_id": agent_id,
        "lookup_agent": lambda sid: lookup_session_agent(conn, sid),
        "turn_counter": turn_counter,
        "source_file": path,
        "line_hash": "",
    }

    extracted = 0
    imported = 0
    parsed_lines = 0
    skipped_lines = 0
    touched: set[tuple[str | None, int]] = set()
    pending: list[dict] = []
    boundary_drops: list[tuple[str, list[tuple[str, int]]]] = []
    new_offset = offset

    try:
        handle = open(path, "rb")
    except OSError as exc:
        return {"path": path, "error": str(exc), "imported": 0}

    with handle:
        handle.seek(offset)
        while True:
            line = handle.readline()
            if not line:
                break
            if not line.endswith(b"\n"):
                # Partial write at the tail; leave it for the next sync.
                break
            new_offset = handle.tell()
            line_no += 1
            stripped = line.strip()
            if not stripped:
                continue
            parsed_lines += 1
            ctx["line_hash"] = hashlib.sha1(stripped).hexdigest()[:16]
            try:
                rec = json.loads(stripped.decode("utf-8", errors="replace"))
            except Exception:
                skipped_lines += 1
                continue
            if not isinstance(rec, dict):
                skipped_lines += 1
                continue

            try:
                events = extract_events(rec, ctx)
            except Exception:
                skipped_lines += 1
                continue
            for event in events:
                drops = event.pop("drops", None)
                pending.append(event)
                extracted += 1
                if event.get("session_id") is not None:
                    touched.add((event.get("session_id"), int(event.get("turn_index") or 0)))
                if drops:
                    boundary_drops.append((event["event_key"], drops))

            if len(pending) >= BATCH_SIZE:
                imported += _insert_events(conn, pending)
                conn.commit()
                pending.clear()

    imported += _insert_events(conn, pending)
    pending.clear()

    # An explicit agent (hook / ingest tool) owns this session. Backfill any
    # events that the watcher imported before the mapping was known.
    if agent_id and ctx.get("session_id"):
        register_session_agent(conn, ctx["session_id"], agent_id)

    # Record exactly which context messages each compaction removed.
    for event_key, drops in boundary_drops:
        found = conn.execute("SELECT id FROM events WHERE event_key = ?", (event_key,)).fetchone()
        if not found:
            continue
        event_id = int(found["id"])
        conn.executemany(
            "INSERT OR IGNORE INTO compaction_drops(event_id, uuid, preserved) VALUES (?, ?, ?)",
            [(event_id, uuid, preserved) for uuid, preserved in drops],
        )

    # Refresh deterministic turn digests for everything we just touched.
    digest_count = 0
    for sid, turn in touched:
        if sid and turn > 0:
            if rebuild_digest(conn, sid, turn) is not None:
                digest_count += 1

    fingerprint = _fingerprint(path, new_offset) if new_offset > 0 else ""
    state_agent = (
        agent_id
        or lookup_session_agent(conn, ctx.get("session_id"))
        or "legacy"
    )
    conn.execute(
        """
        INSERT INTO import_state(
            path, size, mtime, offset, line_no, turn_counter, session_id,
            agent_id, fingerprint, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(path) DO UPDATE SET
            size=excluded.size, mtime=excluded.mtime, offset=excluded.offset,
            line_no=excluded.line_no, turn_counter=excluded.turn_counter,
            session_id=excluded.session_id, agent_id=excluded.agent_id,
            fingerprint=excluded.fingerprint, updated_at=excluded.updated_at
        """,
        (
            path,
            stat.st_size,
            stat.st_mtime,
            new_offset,
            line_no,
            ctx["turn_counter"],
            ctx.get("session_id"),
            state_agent,
            fingerprint,
            now_iso(),
        ),
    )
    conn.commit()

    result = {
        "path": path,
        "session_id": ctx.get("session_id"),
        "agent_id": state_agent,
        "imported": imported,
        "extracted": extracted,
        "parsed_lines": parsed_lines,
        "skipped_lines": skipped_lines,
        "digests": digest_count,
        "offset": new_offset,
        "bytes": stat.st_size,
        "rewritten": rewritten,
        "old_offset": old_offset,
    }
    if verbose:
        print(f"  {Path(path).name}: +{imported} events, {digest_count} digests")
    return result


def sync_all(
    conn: sqlite3.Connection,
    cfg: dict,
    roots: list[str] | None = None,
    since_days: float | None = None,
    verbose: bool = True,
    agent_id: str | None = None,
) -> dict:
    paths = discover_transcripts(roots or cfg.get("transcript_roots") or [], since_days)
    total_events = 0
    errors: list[str] = []
    if verbose:
        print(f"发现 {len(paths)} 个 transcript 文件")
    for index, path in enumerate(paths, 1):
        if verbose:
            print(f"[{index}/{len(paths)}] {Path(path).name}")
        result = sync_transcript(
            conn, path, cfg, verbose=False, agent_id=agent_id
        )
        if result.get("error"):
            errors.append(f"{path}: {result['error']}")
        else:
            total_events += int(result.get("imported") or 0)
    return {"files": len(paths), "events": total_events, "errors": errors}
