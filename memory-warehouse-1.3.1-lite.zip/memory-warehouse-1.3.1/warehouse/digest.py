from __future__ import annotations

import sqlite3
from collections import Counter

from .textutil import (
    clip,
    extract_must_keep,
    json_compact,
    safe_json_loads,
    short_path,
)


def compose_summary(det: str, llm: str | None, must_keep: list[str] | None = None) -> str:
    """Prefer the semantic summary; append exact identifiers either way."""
    if not llm or not llm.strip():
        return det
    out = llm.strip()
    if must_keep:
        out += "\n关键标识：" + "; ".join(clip(item, 80) for item in must_keep[:8])
    return out


def rebuild_digest(conn: sqlite3.Connection, session_id: str, turn_index: int) -> int | None:
    """Build/refresh the deterministic L2 digest for one turn.

    Returns the digest id, or None when the turn has no usable events.
    """
    rows = conn.execute(
        """
        SELECT id, ts, role, kind, content, cwd, meta, agent_id
        FROM events
        WHERE session_id = ? AND turn_index = ? AND is_sidechain = 0
        ORDER BY id
        """,
        (session_id, turn_index),
    ).fetchall()
    if not rows:
        return None

    prompts: list[str] = []
    assistant_texts: list[str] = []
    tools: Counter[str] = Counter()
    files: list[str] = []
    commands: list[str] = []
    errors: list[str] = []
    notes: list[str] = []
    cwds: Counter[str] = Counter()
    agents: Counter[str] = Counter()
    all_text: list[str] = []
    first_id = rows[0]["id"]
    last_id = rows[-1]["id"]
    started = rows[0]["ts"]
    ended = rows[-1]["ts"]

    for row in rows:
        kind = row["kind"]
        content = row["content"] or ""
        meta = safe_json_loads(row["meta"]) or {}
        if row["cwd"]:
            cwds[row["cwd"]] += 1
        if row["agent_id"]:
            agents[row["agent_id"]] += 1
        if kind == "prompt":
            prompts.append(content)
            all_text.append(content)
        elif kind == "text":
            assistant_texts.append(content)
            all_text.append(content)
        elif kind == "tool_use":
            name = meta.get("tool_name") or "tool"
            tools[name] += 1
            for path in meta.get("files") or []:
                if path not in files:
                    files.append(path)
            for command in meta.get("commands") or []:
                if command not in commands:
                    commands.append(command)
            all_text.append(content)
        elif kind == "tool_result":
            if meta.get("is_error"):
                errors.append(content)
            all_text.append(content)
        elif kind in {"note", "checkpoint"}:
            notes.append(content)
            all_text.append(content)
        elif kind in {"compaction_summary", "compact_boundary"}:
            all_text.append(content)

    user_text = "\n".join(prompts).strip()
    assistant_text = assistant_texts[-1].strip() if assistant_texts else ""

    parts: list[str] = []
    if user_text:
        parts.append("用户：" + clip(user_text, 320))
    if assistant_text:
        parts.append("结果：" + clip(assistant_text, 420))
    if len(assistant_texts) > 1:
        first = assistant_texts[0].strip()
        if first and first != assistant_text and first not in assistant_text and len(first) > 20:
            parts.append("早期：" + clip(first, 260))
    if notes:
        parts.append("记录：" + clip(notes[-1], 240))
    if tools:
        parts.append("工具：" + ", ".join(f"{name}×{count}" for name, count in tools.most_common(8)))
    if files:
        parts.append("文件：" + ", ".join(short_path(path) for path in files[:6]))
    if commands:
        parts.append("命令：" + "; ".join(clip(command, 90) for command in commands[:4]))
    if errors:
        parts.append("报错：" + clip(errors[-1], 260))

    # Keep exact identifiers, which summaries tend to lose.
    must_keep = extract_must_keep("\n".join(all_text[-8:]), limit=20)
    summary_det = "\n".join(parts)
    if must_keep:
        summary_det += "\n关键标识：" + "; ".join(clip(item, 80) for item in must_keep[:8])

    existing = conn.execute(
        "SELECT llm_summary FROM digests WHERE session_id = ? AND turn_index = ?",
        (session_id, turn_index),
    ).fetchone()
    llm_summary = existing["llm_summary"] if existing else None
    summary = compose_summary(summary_det, llm_summary, must_keep)

    cwd = cwds.most_common(1)[0][0] if cwds else None
    agent_id = agents.most_common(1)[0][0] if agents else "legacy"

    conn.execute(
        """
        INSERT INTO digests (
            session_id, agent_id, turn_index, cwd, started_at, ended_at, user_text,
            assistant_text, summary, summary_det, tools, files, commands, errors,
            must_keep, event_start, event_end, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(session_id, turn_index) DO UPDATE SET
            agent_id=excluded.agent_id,
            cwd=excluded.cwd, started_at=excluded.started_at, ended_at=excluded.ended_at,
            user_text=excluded.user_text, assistant_text=excluded.assistant_text,
            summary=excluded.summary, summary_det=excluded.summary_det,
            tools=excluded.tools, files=excluded.files,
            commands=excluded.commands, errors=excluded.errors, must_keep=excluded.must_keep,
            event_start=excluded.event_start, event_end=excluded.event_end,
            updated_at=excluded.updated_at
        """,
        (
            session_id,
            agent_id,
            turn_index,
            cwd,
            started,
            ended,
            user_text[:2000],
            assistant_text[:4000],
            summary,
            summary_det,
            json_compact(dict(tools)),
            json_compact(files[:24]),
            json_compact(commands[:16]),
            json_compact(errors[-5:]),
            json_compact(must_keep),
            first_id,
            last_id,
            started,
        ),
    )
    row = conn.execute(
        "SELECT id FROM digests WHERE session_id = ? AND turn_index = ?",
        (session_id, turn_index),
    ).fetchone()
    return int(row["id"]) if row else None


def rebuild_all(conn: sqlite3.Connection, limit: int | None = None) -> int:
    query = """
        SELECT session_id, turn_index FROM events
        WHERE turn_index > 0 AND session_id IS NOT NULL
        GROUP BY session_id, turn_index
        ORDER BY MAX(id) DESC
    """
    if limit:
        query += f" LIMIT {int(limit)}"
    keys = conn.execute(query).fetchall()
    count = 0
    for row in keys:
        if rebuild_digest(conn, row["session_id"], row["turn_index"]) is not None:
            count += 1
    conn.commit()
    return count
