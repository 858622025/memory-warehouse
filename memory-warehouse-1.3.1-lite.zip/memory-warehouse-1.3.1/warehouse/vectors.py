"""V3: local chunked embeddings and semantic candidate retrieval.

Uses fastembed with BAAI/bge-small-zh-v1.5 (512 dims, ~90MB ONNX). Each event or
digest is split into sentence-sized chunks, embedded separately, and stored as
L2-normalized float32 BLOBs. Retrieval takes the best chunk per item, then
search.py fuses the candidates with BM25 via Reciprocal Rank Fusion.

Chunking matters: a long "turn summary" otherwise averages away the one
sentence that actually answers the query.
"""
from __future__ import annotations

import hashlib
import os
import re
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

from .config import ROOT
from .textutil import clip, normalize_cwd, now_iso

DEFAULT_MODEL = "BAAI/bge-small-zh-v1.5"
DEFAULT_MODEL_PATH = ROOT / "data" / "models" / "bge-small-zh-v1.5"
EVENT_KINDS = ("prompt", "text", "note", "checkpoint", "compaction_summary")
CHUNK_MAX_CHARS = 120
MAX_CHUNKS = 6

_MODEL_CACHE: dict[tuple[str, str], object] = {}


def _cfg(cfg: dict) -> dict:
    return cfg.get("embeddings") or {}


def model_path(cfg: dict) -> Path:
    raw = _cfg(cfg).get("model_path") or DEFAULT_MODEL_PATH
    path = Path(raw)
    return path if path.is_absolute() else ROOT / path


def model_name(cfg: dict) -> str:
    return _cfg(cfg).get("model") or DEFAULT_MODEL


def _load_model(cfg: dict):
    name = model_name(cfg)
    path = model_path(cfg)
    key = (name, str(path))
    if key in _MODEL_CACHE:
        return _MODEL_CACHE[key]
    if not path.exists():
        raise RuntimeError(
            f"embedding model not found: {path}. Download it before running `mw.py embed`."
        )
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    from fastembed import TextEmbedding

    model = TextEmbedding(model_name=name, specific_model_path=str(path))
    _MODEL_CACHE[key] = model
    return model


def _embed(texts: list[str], cfg: dict):
    import numpy as np

    model = _load_model(cfg)
    batch_size = int(_cfg(cfg).get("batch_size", 32))
    chunks: list = []
    for start in range(0, len(texts), batch_size):
        batch = [text[:4000] for text in texts[start : start + batch_size]]
        chunks.append(np.asarray(list(model.embed(batch)), dtype=np.float32))
    if not chunks:
        return np.zeros((0, 0), dtype=np.float32)
    matrix = np.vstack(chunks)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return matrix / norms


def embed_query(text: str, cfg: dict):
    import numpy as np

    prefix = _cfg(cfg).get("query_prefix", "为这个句子生成表示以用于检索相关文章：")
    matrix = _embed([f"{prefix}{text}"], cfg)
    return matrix[0] if len(matrix) else np.zeros(0, dtype=np.float32)


def _hash(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8", errors="replace")).hexdigest()


def _chunks(text: str) -> list[str]:
    """Full text + overlapping clause windows.

    The full text keeps global context; two-clause windows keep the local
    phrase ("上下文爆掉后，能找回失去的记忆") intact instead of slicing it at
    an arbitrary character boundary.
    """
    text = (text or "").strip()
    if not text:
        return []
    clauses = [
        part
        for part in re.split(r"(?<=[。！？!?；;，,、\n])", text)
        if part.strip()
    ]
    windows: list[str] = []
    for index in range(len(clauses)):
        window = clauses[index]
        if index + 1 < len(clauses):
            window += clauses[index + 1]
        if len(window) < 20 and index + 2 < len(clauses):
            window += clauses[index + 2]
        windows.append(window[:CHUNK_MAX_CHARS])

    picked: list[str] = []
    if windows:
        picked.extend(windows[:4])
        if len(windows) > 4:
            picked.extend(windows[-2:])
    chunks = [text[:400]] + picked
    seen: set[str] = set()
    out: list[str] = []
    for chunk in chunks:
        key = chunk.strip()
        if len(key) < 2 or key in seen:
            continue
        seen.add(key)
        out.append(key)
        if len(out) >= MAX_CHUNKS:
            break
    return out or [text[:CHUNK_MAX_CHARS]]


def _targets(conn: sqlite3.Connection, cfg: dict) -> list[tuple[str, int, str]]:
    targets: list[tuple[str, int, str]] = []
    rows = conn.execute(
        """
        SELECT id, user_text, assistant_text, summary, summary_det
        FROM digests
        ORDER BY COALESCE(ended_at, started_at) DESC
        """
    ).fetchall()
    for row in rows:
        text = (
            (row["user_text"] or "").strip()
            + "\n"
            + (row["assistant_text"] or "")[:900].strip()
        ).strip()
        if len(text) < 8:
            text = (row["summary"] or row["summary_det"] or "").strip()
        if len(text) >= 8:
            targets.append(("digest", int(row["id"]), text))

    max_events = int(_cfg(cfg).get("max_events", 40000))
    placeholders = ",".join("?" for _ in EVENT_KINDS)
    rows = conn.execute(
        f"""
        SELECT id, kind, content FROM events
        WHERE kind IN ({placeholders}) AND LENGTH(content) >= 8
        ORDER BY ts DESC, id DESC LIMIT ?
        """,
        (*EVENT_KINDS, max_events),
    ).fetchall()
    per_kind_cap = {
        "prompt": 1000,
        "text": 1200,
        "note": 1200,
        "checkpoint": 1200,
        "compaction_summary": 1200,
    }
    for row in rows:
        text = (row["content"] or "").strip()
        if len(text) >= 8:
            targets.append(
                ("event", int(row["id"]), text[: per_kind_cap.get(row["kind"], 800)])
            )
    return targets


def vector_stats(conn: sqlite3.Connection) -> dict:
    try:
        total_chunks = conn.execute("SELECT COUNT(*) FROM vector_chunks").fetchone()[0]
        refs = conn.execute(
            "SELECT COUNT(*) FROM (SELECT DISTINCT kind, ref_id FROM vector_chunks)"
        ).fetchone()[0]
        by_kind = {
            row["kind"]: row["n"]
            for row in conn.execute(
                "SELECT kind, COUNT(DISTINCT ref_id) AS n FROM vector_chunks GROUP BY kind"
            )
        }
        model_row = conn.execute("SELECT model FROM vector_chunks LIMIT 1").fetchone()
    except sqlite3.OperationalError:
        return {"total": 0, "chunks": 0, "events": 0, "digests": 0, "model": None}
    return {
        "total": refs,
        "chunks": total_chunks,
        "events": by_kind.get("event", 0),
        "digests": by_kind.get("digest", 0),
        "model": model_row[0] if model_row else None,
    }


def available(conn: sqlite3.Connection, cfg: dict) -> bool:
    if not _cfg(cfg).get("enabled", True):
        return False
    if not model_path(cfg).exists():
        return False
    try:
        return conn.execute("SELECT COUNT(*) FROM vector_chunks").fetchone()[0] > 0
    except sqlite3.OperationalError:
        return False


_LOCK_PATH = ROOT / "data" / "embed.lock"


def _acquire_lock() -> bool:
    try:
        fd = os.open(_LOCK_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
        return True
    except FileExistsError:
        try:
            if time.time() - _LOCK_PATH.stat().st_mtime > 1800:
                _LOCK_PATH.unlink()
                return _acquire_lock()
        except Exception:
            pass
        return False
    except OSError:
        return True  # a read-only or missing data dir should not block search


def _release_lock() -> None:
    try:
        _LOCK_PATH.unlink()
    except OSError:
        pass


def build_vectors(
    conn: sqlite3.Connection,
    cfg: dict,
    force: bool = False,
    limit: int | None = None,
    verbose: bool = True,
) -> dict:
    if not model_path(cfg).exists():
        message = f"embedding model not found: {model_path(cfg)}"
        if verbose:
            print(message + "；跳过向量构建，FTS 检索仍然可用。")
        return {
            "targets": 0,
            "embedded": 0,
            "chunks": 0,
            "model": model_name(cfg),
            "skipped": "model_missing",
        }
    if not _acquire_lock():
        if verbose:
            print("另一个 embed 进程正在运行，本次跳过")
        return {"targets": 0, "embedded": 0, "chunks": 0, "model": model_name(cfg), "skipped": "locked"}
    try:
        return _build_vectors_impl(conn, cfg, force=force, limit=limit, verbose=verbose)
    finally:
        _release_lock()


def _build_vectors_impl(
    conn: sqlite3.Connection,
    cfg: dict,
    force: bool = False,
    limit: int | None = None,
    verbose: bool = True,
) -> dict:
    name = model_name(cfg)
    targets = _targets(conn, cfg)
    existing = {
        (row["kind"], row["ref_id"]): (row["group_hash"], row["model"])
        for row in conn.execute(
            "SELECT kind, ref_id, MAX(group_hash) AS group_hash, MAX(model) AS model "
            "FROM vector_chunks GROUP BY kind, ref_id"
        )
    }
    todo: list[tuple[str, int, str]] = []
    for kind, ref_id, text in targets:
        group_hash = _hash(text)
        old = existing.get((kind, ref_id))
        if not force and old and old[0] == group_hash and old[1] == name:
            continue
        todo.append((kind, ref_id, text))
        if limit and len(todo) >= limit:
            break

    if verbose:
        print(f"目标 {len(targets)} 条，需要嵌入 {len(todo)} 条，模型 {name}")
    if not todo:
        return {"targets": len(targets), "embedded": 0, "chunks": 0, "model": name}

    batch_targets = int(_cfg(cfg).get("batch_targets", 16))
    embedded = 0
    total_chunks = 0
    now = now_iso()
    for start in range(0, len(todo), batch_targets):
        batch = todo[start : start + batch_targets]
        chunk_lists = [_chunks(text) for _, _, text in batch]
        flat = [chunk for chunks in chunk_lists for chunk in chunks]
        matrix = _embed(flat, cfg)
        offset = 0
        for (kind, ref_id, text), chunks in zip(batch, chunk_lists):
            group_hash = _hash(text)
            conn.execute(
                "DELETE FROM vector_chunks WHERE kind = ? AND ref_id = ?",
                (kind, ref_id),
            )
            rows = []
            for chunk_index, chunk in enumerate(chunks):
                vector = matrix[offset]
                offset += 1
                rows.append(
                    (
                        kind,
                        ref_id,
                        chunk_index,
                        name,
                        int(vector.shape[0]),
                        group_hash,
                        _hash(chunk),
                        vector.tobytes(),
                        now,
                    )
                )
            conn.executemany(
                """
                INSERT OR REPLACE INTO vector_chunks(
                    kind, ref_id, chunk_idx, model, dim, group_hash,
                    content_hash, vec, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                rows,
            )
            total_chunks += len(rows)
        conn.commit()
        embedded += len(batch)
        if verbose and (start // batch_targets) % 10 == 0:
            print(f"  已处理 {embedded}/{len(todo)} 条（{total_chunks} 个块）")

    # The old single-vector table is superseded; free its space.
    try:
        conn.execute("DELETE FROM vectors")
        conn.commit()
    except sqlite3.OperationalError:
        pass

    if verbose:
        print(f"完成：{embedded} 条目标，{total_chunks} 个向量块")
    return {
        "targets": len(targets),
        "embedded": embedded,
        "chunks": total_chunks,
        "model": name,
    }


def _event_filters(cwd, session, since, until, kinds, agent_id=None) -> tuple[str, list]:
    clauses: list[str] = []
    params: list = []
    cwd = normalize_cwd(cwd)
    if agent_id != "*":
        target = agent_id or "legacy"
        if target == "legacy":
            clauses.append("(e.agent_id = ? OR e.agent_id IS NULL)")
        else:
            clauses.append("e.agent_id = ?")
        params.append(target)
    if cwd:
        clauses.append("e.cwd = ? COLLATE NOCASE")
        params.append(cwd)
    if session:
        clauses.append("e.session_id LIKE ?")
        params.append(f"{session}%")
    if since:
        clauses.append("e.ts >= ?")
        params.append(since)
    if until:
        clauses.append("e.ts <= ?")
        params.append(until)
    usable = [k for k in (kinds or []) if k != "digest"]
    if kinds:
        if usable:
            clauses.append(f"e.kind IN ({','.join('?' for _ in usable)})")
            params.extend(usable)
        else:
            clauses.append("1=0")
    return (" AND " + " AND ".join(clauses) if clauses else ""), params


def _digest_filters(cwd, session, since, until, agent_id=None) -> tuple[str, list]:
    clauses: list[str] = []
    params: list = []
    cwd = normalize_cwd(cwd)
    if agent_id != "*":
        target = agent_id or "legacy"
        if target == "legacy":
            clauses.append("(d.agent_id = ? OR d.agent_id IS NULL)")
        else:
            clauses.append("d.agent_id = ?")
        params.append(target)
    if cwd:
        clauses.append("d.cwd = ? COLLATE NOCASE")
        params.append(cwd)
    if session:
        clauses.append("d.session_id LIKE ?")
        params.append(f"{session}%")
    if since:
        clauses.append("COALESCE(d.ended_at, d.started_at) >= ?")
        params.append(since)
    if until:
        clauses.append("COALESCE(d.ended_at, d.started_at) <= ?")
        params.append(until)
    return (" AND " + " AND ".join(clauses) if clauses else ""), params


def _best_per_ref(rows, scores, builder) -> list[dict]:
    best: dict[tuple[str, int], dict] = {}
    for index, row in enumerate(rows):
        key = (row["kind"], int(row["ref_id"]))
        score = float(scores[index])
        if key not in best or score > best[key]["score"]:
            best[key] = builder(row, score)
    return list(best.values())


def semantic_search(
    conn: sqlite3.Connection,
    cfg: dict,
    query: str,
    *,
    limit: int = 30,
    cwd: str | None = None,
    session: str | None = None,
    kinds: list[str] | None = None,
    since: str | None = None,
    until: str | None = None,
    agent_id: str | None = None,
) -> list[dict]:
    import numpy as np

    if not available(conn, cfg) or not (query or "").strip():
        return []
    query_vec = embed_query(query, cfg)
    if query_vec.size == 0:
        return []

    results: list[dict] = []
    want_events = not kinds or any(kind != "digest" for kind in kinds)
    want_digests = not kinds or "digest" in kinds

    if want_events:
        filters, params = _event_filters(
            cwd, session, since, until, kinds, agent_id=agent_id
        )
        rows = conn.execute(
            f"""
            SELECT v.ref_id, v.vec, v.dim, e.ts, e.role, e.kind, e.content,
                   e.cwd, e.session_id, e.agent_id, e.turn_index
            FROM vector_chunks v JOIN events e ON e.id = v.ref_id
            WHERE v.kind = 'event' {filters}
            """,
            params,
        ).fetchall()
        if rows:
            dim = int(rows[0]["dim"])
            matrix = np.frombuffer(b"".join(row["vec"] for row in rows), dtype=np.float32)
            scores = matrix.reshape(-1, dim) @ query_vec
            results.extend(
                _best_per_ref(
                    rows,
                    scores,
                    lambda row, score: {
                        "type": "event",
                        "id": row["ref_id"],
                        "ts": row["ts"],
                        "role": row["role"],
                        "kind": row["kind"],
                        "content": row["content"] or "",
                        "snippet": clip(row["content"] or "", 260),
                        "cwd": row["cwd"],
                        "session_id": row["session_id"],
                        "agent_id": row["agent_id"],
                        "turn_index": row["turn_index"],
                        "score": score,
                    },
                )
            )

    if want_digests:
        filters, params = _digest_filters(
            cwd, session, since, until, agent_id=agent_id
        )
        rows = conn.execute(
            f"""
            SELECT v.ref_id, v.vec, v.dim, 'digest' AS kind,
                   d.started_at, d.ended_at, d.summary,
                   d.cwd, d.session_id, d.agent_id, d.turn_index
            FROM vector_chunks v JOIN digests d ON d.id = v.ref_id
            WHERE v.kind = 'digest' {filters}
            """,
            params,
        ).fetchall()
        if rows:
            dim = int(rows[0]["dim"])
            matrix = np.frombuffer(b"".join(row["vec"] for row in rows), dtype=np.float32)
            scores = matrix.reshape(-1, dim) @ query_vec
            results.extend(
                _best_per_ref(
                    rows,
                    scores,
                    lambda row, score: {
                        "type": "digest",
                        "id": row["ref_id"],
                        "ts": row["ended_at"] or row["started_at"],
                        "role": "agent",
                        "kind": "digest",
                        "content": row["summary"] or "",
                        "snippet": clip(row["summary"] or "", 300),
                        "cwd": row["cwd"],
                        "session_id": row["session_id"],
                        "agent_id": row["agent_id"],
                        "turn_index": row["turn_index"],
                        "score": score,
                    },
                )
            )

    results.sort(key=lambda item: item["score"], reverse=True)
    threshold = float(_cfg(cfg).get("min_score", 0.25))
    return [item for item in results if item["score"] >= threshold][:limit]


def spawn_auto_embed(cfg: dict) -> bool:
    """Detached incremental embedding after a turn."""
    if not _cfg(cfg).get("auto_build", True):
        return False
    if not model_path(cfg).exists():
        return False
    command = [sys.executable, str(ROOT / "mw.py"), "embed", "--quiet"]
    kwargs = {
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "cwd": str(ROOT),
    }
    if os.name == "nt":
        kwargs["creationflags"] = (
            getattr(subprocess, "CREATE_NO_WINDOW", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
        )
    try:
        subprocess.Popen(command, **kwargs)
        return True
    except Exception:
        return False
