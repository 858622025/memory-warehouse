@echo off
python "%~dp0mw.py" %*
