from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

from warehouse import llm, vectors
from warehouse.brief import build_brief
from warehouse.cli import _insert_manual_event
from warehouse.db import connect
from warehouse.digest import compose_summary, rebuild_digest
from warehouse.hooks import create_checkpoint_from_tail
from warehouse.importer import sync_transcript
from warehouse.search import _rrf_fuse, lost_events, search, show_event
from warehouse.textutil import extract_must_keep, redact
from warehouse.watcher import TranscriptWatcher, read_watcher_stats

CFG = {
    "caps": {
        "prompt": 4000,
        "text": 6000,
        "thinking": 2000,
        "tool_use": 4000,
        "tool_result": 3000,
        "compaction_summary": 12000,
        "compact_boundary": 2000,
        "system": 2000,
        "image": 200,
        "checkpoint": 8000,
        "note": 8000,
    },
    "redact": True,
    "brief_max_chars": 3000,
    "brief_recent_digests": 5,
    "brief_checkpoints": 2,
    "transcript_roots": [],
}


def record(rtype: str, uuid: str, content, ts: str, **extra):
    base = {
        "type": rtype,
        "uuid": uuid,
        "timestamp": ts,
        "sessionId": "session-test",
        "cwd": "C:\\proj",
    }
    if rtype in ("user", "assistant"):
        base["message"] = {
            "role": rtype,
            "content": content,
        }
    base.update(extra)
    return base


RECORDS = [
    record(
        "user",
        "u1",
        "记忆仓库的数据库怎么设计？",
        "2026-10-01T10:00:00.000Z",
        promptId="p1",
    ),
    record(
        "assistant",
        "a1",
        [{"type": "text", "text": "用 SQLite 加 FTS5，支持三元组检索。"}],
        "2026-10-01T10:00:01.000Z",
    ),
    record(
        "assistant",
        "a2",
        [
            {
                "type": "tool_use",
                "id": "tool-1",
                "name": "Bash",
                "input": {"command": "python mw.py recall 数据库"},
            }
        ],
        "2026-10-01T10:00:02.000Z",
    ),
    record(
        "user",
        "u2",
        [{"type": "tool_result", "tool_use_id": "tool-1", "content": "ok"}],
        "2026-10-01T10:00:03.000Z",
    ),
    record(
        "assistant",
        "a3",
        [{"type": "text", "text": "完成。文件是 C:\\proj\\mw.py，命令 npm run build。"}],
        "2026-10-01T10:00:04.000Z",
    ),
    {
        "type": "system",
        "subtype": "compact_boundary",
        "uuid": "cb1",
        "timestamp": "2026-10-01T10:01:00.000Z",
        "sessionId": "session-test",
        "cwd": "C:\\proj",
        "content": "Conversation compacted",
        "compactMetadata": {
            "trigger": "auto",
            "preTokens": 1000,
            "postTokens": 100,
            "preservedMessages": {
                "uuids": ["a3"],
                "allUuids": ["u1", "a1", "a2", "u2", "a3"],
            },
        },
    },
    record(
        "user",
        "u3",
        "This session continued. Summary: 之前讨论了 SQLite 方案。",
        "2026-10-01T10:01:01.000Z",
        isCompactSummary=True,
    ),
    record(
        "user",
        "u4",
        "第二个问题：怎么装 hook？",
        "2026-10-01T10:02:00.000Z",
        promptId="p2",
    ),
    record(
        "assistant",
        "a4",
        [{"type": "text", "text": "运行 install_hooks.py。"}],
        "2026-10-01T10:02:01.000Z",
    ),
]


class WarehouseTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.db_path = str(self.root / "memory.db")
        self.transcript = self.root / "session-test.jsonl"
        with open(self.transcript, "w", encoding="utf-8") as handle:
            for item in RECORDS:
                handle.write(json.dumps(item, ensure_ascii=False) + "\n")
        self.conn = connect(self.db_path)

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def test_import_and_dedupe(self):
        result = sync_transcript(self.conn, str(self.transcript), CFG)
        self.assertEqual(result["imported"], 9, result)
        self.assertEqual(result["digests"], 2)
        count = self.conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        self.assertEqual(count, 9)

        again = sync_transcript(self.conn, str(self.transcript), CFG)
        self.assertEqual(again["imported"], 0)
        self.assertEqual(
            self.conn.execute("SELECT COUNT(*) FROM events").fetchone()[0], 9
        )

        # Appending one record is picked up incrementally.
        with open(self.transcript, "a", encoding="utf-8") as handle:
            handle.write(
                json.dumps(
                    record(
                        "assistant",
                        "a5",
                        [{"type": "text", "text": "新增的一行"}],
                        "2026-10-01T10:03:00.000Z",
                    ),
                    ensure_ascii=False,
                )
                + "\n"
            )
        third = sync_transcript(self.conn, str(self.transcript), CFG)
        self.assertEqual(third["imported"], 1)

    def test_search_chinese_and_english(self):
        sync_transcript(self.conn, str(self.transcript), CFG)

        hits = search(self.conn, "SQLite")
        self.assertTrue(hits)
        self.assertIn("SQLite", hits[0]["content"])

        hits = search(self.conn, "数据库怎么设计")
        self.assertTrue(hits)

        hits = search(self.conn, "npm run build")
        self.assertTrue(hits)
        self.assertTrue(any("npm run build" in hit["content"] for hit in hits))

        hits = search(self.conn, "hook", kinds=["digest"])
        self.assertTrue(all(hit["type"] == "digest" for hit in hits))

    def test_full_text_roundtrip(self):
        sync_transcript(self.conn, str(self.transcript), CFG)
        event_id = self.conn.execute(
            "SELECT id FROM events WHERE kind='prompt' ORDER BY id LIMIT 1"
        ).fetchone()[0]
        record = show_event(self.conn, int(event_id))
        self.assertIn("数据库怎么设计", record["full_content"])

    def test_compaction_losses(self):
        sync_transcript(self.conn, str(self.transcript), CFG)
        rows = lost_events(self.conn, "session-test")
        kinds = {row["kind"] for row in rows}
        self.assertIn("prompt", kinds)
        self.assertIn("tool_use", kinds)
        self.assertEqual(len(rows), 4)

    def test_digest_rebuild(self):
        sync_transcript(self.conn, str(self.transcript), CFG)
        digest_id = rebuild_digest(self.conn, "session-test", 1)
        self.assertIsNotNone(digest_id)
        row = self.conn.execute(
            "SELECT * FROM digests WHERE session_id='session-test' AND turn_index=1"
        ).fetchone()
        self.assertIn("SQLite", row["summary"])
        self.assertIn("Bash", row["tools"])

    def test_notes_checkpoint_brief(self):
        sync_transcript(self.conn, str(self.transcript), CFG)
        checkpoint_id = create_checkpoint_from_tail(
            self.conn, CFG, "session-test", "C:\\proj", trigger="auto", pre_tokens=999
        )
        self.assertIsNotNone(checkpoint_id)
        note_id = _insert_manual_event(
            self.conn,
            CFG,
            kind="note",
            text="数据库放在 data/memory.db",
            cwd="C:\\proj",
            pinned=True,
            tags=["design"],
        )
        self.assertGreater(note_id, 0)
        brief = build_brief(self.conn, CFG, cwd="C:/proj")
        self.assertIn("记忆仓库", brief)
        self.assertIn("data/memory.db", brief)
        self.assertIn("检查点", brief)

    # ------------------------------------------------------------------
    # V2: semantic summaries
    # ------------------------------------------------------------------

    def test_chunking_keeps_local_phrase(self):
        text = (
            "我在想，agnet每次对话回话，能不能在本地的数据库中存一下历史的信息，"
            "方便上下文爆掉后，能找回一些失去的记忆。有什么想法和思路吗"
        )
        chunks = vectors._chunks(text)
        self.assertTrue(any("上下文爆掉后" in chunk and "找回" in chunk for chunk in chunks))
        self.assertLessEqual(len(chunks), vectors.MAX_CHUNKS)

    def test_summary_json_double_encoded(self):
        inner = {
            "summary": "用户要求记住数据库路径",
            "decisions": ["使用 data/memory.db"],
            "open_questions": [],
            "must_keep": ["C:\\proj\\memory.db"],
        }
        raw = json.dumps(json.dumps(inner, ensure_ascii=False), ensure_ascii=False)
        parsed = llm._parse_summary_json(raw)
        self.assertEqual(parsed["summary"], "用户要求记住数据库路径")
        self.assertEqual(parsed["decisions"], ["使用 data/memory.db"])

    def test_llm_summary_with_fake_call(self):
        sync_transcript(self.conn, str(self.transcript), CFG)
        fake = {
            "summary": "用户问了数据库设计，最终选择 SQLite + FTS5。",
            "decisions": ["使用 SQLite", "使用 FTS5"],
            "open_questions": ["是否需要向量检索"],
            "must_keep": ["C:\\proj\\mw.py", "npm run build"],
        }

        def fake_call(prompt, cfg, model=None, max_tokens=None):
            self.assertIn("对话", prompt)
            return json.dumps(fake, ensure_ascii=False)

        with mock.patch.object(llm, "call_llm", fake_call):
            result = llm.summarize_turn(
                self.conn, CFG, "session-test", 1, force=True
            )
        self.assertEqual(result["summary"], fake["summary"])
        row = self.conn.execute(
            "SELECT * FROM digests WHERE session_id='session-test' AND turn_index=1"
        ).fetchone()
        self.assertEqual(row["llm_summary"], fake["summary"])
        self.assertIn("SQLite + FTS5", row["summary"])
        self.assertIn("C:\\proj\\mw.py", json.loads(row["must_keep"]))

        # Deterministic rebuild must preserve the LLM summary.
        rebuild_digest(self.conn, "session-test", 1)
        self.conn.commit()
        row = self.conn.execute(
            "SELECT summary, llm_summary FROM digests WHERE session_id='session-test' AND turn_index=1"
        ).fetchone()
        self.assertEqual(row["llm_summary"], fake["summary"])
        self.assertIn("SQLite + FTS5", row["summary"])

    def test_compose_summary(self):
        self.assertEqual(compose_summary("det", None, []), "det")
        composed = compose_summary("det", "semantic", ["C:\\a.py"])
        self.assertIn("semantic", composed)
        self.assertIn("C:\\a.py", composed)

    # ------------------------------------------------------------------
    # V3: vector retrieval and fusion
    # ------------------------------------------------------------------

    def test_vector_semantic_search(self):
        sync_transcript(self.conn, str(self.transcript), CFG)
        event_id = self.conn.execute(
            "SELECT id FROM events WHERE kind='prompt' ORDER BY id LIMIT 1"
        ).fetchone()[0]
        digest_id = self.conn.execute("SELECT id FROM digests ORDER BY id LIMIT 1").fetchone()[0]

        model_file = self.root / "fake-model.onnx"
        model_file.write_bytes(b"x")
        vcfg = {
            "embeddings": {
                "enabled": True,
                "model_path": str(model_file),
                "min_score": 0.1,
            }
        }

        vec_a = np.array([1.0, 0.0], dtype=np.float32)
        vec_b = np.array([0.9, 0.1], dtype=np.float32)
        vec_b = vec_b / np.linalg.norm(vec_b)
        self.conn.execute(
            "INSERT INTO vector_chunks(kind, ref_id, chunk_idx, model, dim, group_hash, content_hash, vec, updated_at) "
            "VALUES ('event', ?, 0, 'fake', 2, 'g', 'h', ?, 'now')",
            (event_id, vec_a.tobytes()),
        )
        self.conn.execute(
            "INSERT INTO vector_chunks(kind, ref_id, chunk_idx, model, dim, group_hash, content_hash, vec, updated_at) "
            "VALUES ('digest', ?, 0, 'fake', 2, 'g', 'h', ?, 'now')",
            (digest_id, vec_b.tobytes()),
        )
        self.conn.commit()

        with mock.patch.object(vectors, "embed_query", lambda text, cfg: vec_a):
            results = vectors.semantic_search(
                self.conn, vcfg, "任意查询", limit=5
            )
        self.assertTrue(results)
        self.assertEqual(results[0]["type"], "event")
        self.assertEqual(results[0]["id"], event_id)

    def test_rrf_fusion(self):
        def item(kind, id_, score=1.0):
            return {
                "type": kind,
                "id": id_,
                "ts": "2026-10-01T00:00:00Z",
                "kind": kind,
                "content": str(id_),
                "snippet": str(id_),
                "score": score,
            }

        bm25 = [item("event", 1), item("event", 2)]
        semantic = [item("event", 2, 0.9), item("event", 3, 0.8)]
        fused = _rrf_fuse(bm25, semantic, limit=3)
        self.assertEqual(fused[0]["id"], 2)  # appears in both lists
        self.assertEqual(fused[0]["source"], "hybrid")

    # ------------------------------------------------------------------
    # MCP alternative: transcript watcher
    # ------------------------------------------------------------------

    def test_watcher_imports_append_and_rewrite(self):
        cfg = dict(CFG)
        cfg["db_path"] = self.db_path
        cfg["transcript_roots"] = [str(self.root)]
        cfg["watcher"] = {
            "enabled": False,
            "auto_embed": False,
            "auto_summarize": False,
            "interval": 0.1,
        }
        watcher = TranscriptWatcher(
            cfg, auto_embed=False, auto_summarize=False
        )

        first = watcher.run_once()
        self.assertEqual(first["files"], 1)
        self.assertEqual(first["imported"], 9)
        self.assertFalse(first["rewrites"])
        self.assertIsNotNone(first["last_poll"])

        # Append one record and poll again.
        with open(self.transcript, "a", encoding="utf-8") as handle:
            handle.write(
                json.dumps(
                    record(
                        "assistant",
                        "a-watch",
                        [{"type": "text", "text": "watch 追加的一行"}],
                        "2026-10-01T10:04:00.000Z",
                    ),
                    ensure_ascii=False,
                )
                + "\n"
            )
        second = watcher.run_once()
        self.assertEqual(second["poll_imported"], 1)

        # Unchanged poll does no work.
        third = watcher.run_once()
        self.assertEqual(third["poll_imported"], 0)

        # Rewrite the transcript with a smaller file (simulates compaction).
        rewrite_records = [
            record(
                "user",
                "r1",
                "压缩之后的新问题",
                "2026-10-01T11:00:00.000Z",
                promptId="p3",
            ),
            record(
                "assistant",
                "r2",
                [{"type": "text", "text": "压缩之后的回答"}],
                "2026-10-01T11:00:01.000Z",
            ),
        ]
        with open(self.transcript, "w", encoding="utf-8") as handle:
            for item in rewrite_records:
                handle.write(json.dumps(item, ensure_ascii=False) + "\n")
        fourth = watcher.run_once()
        self.assertGreaterEqual(fourth["poll_rewrites"], 1)
        self.assertEqual(fourth["poll_imported"], 2)

        # Old events must survive the rewrite.
        count = self.conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        self.assertGreaterEqual(count, 11)
        new_prompt = self.conn.execute(
            "SELECT COUNT(*) FROM events WHERE content LIKE '%压缩之后的新问题%'"
        ).fetchone()[0]
        self.assertEqual(new_prompt, 1)
        # A rewrite must not reset turn numbering and overwrite old digests.
        self.assertGreaterEqual(
            self.conn.execute("SELECT COUNT(*) FROM digests").fetchone()[0], 3
        )

        stored = read_watcher_stats(self.conn)
        self.assertIn("last_poll", stored)
        self.assertTrue(watcher.status()["last_poll"])

    def test_redaction_and_must_keep(self):
        self.assertNotIn("sk-abcdefghijklmnop", redact("key sk-abcdefghijklmnop end"))
        self.assertIn("[REDACTED_KEY]", redact("key sk-abcdefghijklmnop end"))
        items = extract_must_keep(
            "错误在 C:\\proj\\mw.py，命令 `npm run build`，参考《游戏王》和 https://example.com/a"
        )
        joined = "\n".join(items)
        self.assertIn("C:\\proj\\mw.py", joined)
        self.assertIn("npm run build", joined)
        self.assertIn("《游戏王》", joined)
        self.assertIn("https://example.com/a", joined)


if __name__ == "__main__":
    unittest.main()
