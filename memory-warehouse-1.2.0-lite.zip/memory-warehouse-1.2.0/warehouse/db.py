from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA = r"""
CREATE TABLE IF NOT EXISTS events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    event_key     TEXT NOT NULL UNIQUE,
    session_id    TEXT,
    turn_index    INTEGER NOT NULL DEFAULT 0,
    ts            TEXT,
    role          TEXT,
    kind          TEXT,
    content       TEXT NOT NULL DEFAULT '',
    cwd           TEXT,
    source        TEXT,
    source_uuid   TEXT,
    source_file   TEXT,
    block_index   INTEGER,
    is_sidechain  INTEGER NOT NULL DEFAULT 0,
    pinned        INTEGER NOT NULL DEFAULT 0,
    tags          TEXT,
    meta          TEXT,
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_events_session_turn ON events(session_id, turn_index);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
CREATE INDEX IF NOT EXISTS idx_events_cwd ON events(cwd COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_events_kind ON events(kind);
CREATE INDEX IF NOT EXISTS idx_events_pinned ON events(pinned);
CREATE INDEX IF NOT EXISTS idx_events_uuid ON events(source_uuid);

CREATE VIRTUAL TABLE IF NOT EXISTS events_fts USING fts5(
    content,
    content='events',
    content_rowid='id',
    tokenize='trigram'
);

CREATE TRIGGER IF NOT EXISTS events_ai AFTER INSERT ON events BEGIN
    INSERT INTO events_fts(rowid, content) VALUES (new.id, new.content);
END;

CREATE TRIGGER IF NOT EXISTS events_ad AFTER DELETE ON events BEGIN
    INSERT INTO events_fts(events_fts, rowid, content) VALUES ('delete', old.id, old.content);
END;

CREATE TRIGGER IF NOT EXISTS events_au AFTER UPDATE OF content ON events BEGIN
    INSERT INTO events_fts(events_fts, rowid, content) VALUES ('delete', old.id, old.content);
    INSERT INTO events_fts(rowid, content) VALUES (new.id, new.content);
END;

CREATE TABLE IF NOT EXISTS digests (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id     TEXT NOT NULL,
    turn_index     INTEGER NOT NULL,
    cwd            TEXT,
    started_at     TEXT,
    ended_at       TEXT,
    user_text      TEXT,
    assistant_text TEXT,
    summary        TEXT NOT NULL DEFAULT '',
    summary_det    TEXT,
    llm_summary    TEXT,
    decisions      TEXT,
    open_questions TEXT,
    llm_model      TEXT,
    llm_updated_at TEXT,
    tools          TEXT,
    files          TEXT,
    commands       TEXT,
    errors         TEXT,
    must_keep      TEXT,
    event_start    INTEGER,
    event_end      INTEGER,
    updated_at     TEXT,
    UNIQUE(session_id, turn_index)
);

CREATE INDEX IF NOT EXISTS idx_digests_updated ON digests(updated_at);
CREATE INDEX IF NOT EXISTS idx_digests_cwd ON digests(cwd COLLATE NOCASE);

CREATE VIRTUAL TABLE IF NOT EXISTS digests_fts USING fts5(
    summary,
    content='digests',
    content_rowid='id',
    tokenize='trigram'
);

CREATE TRIGGER IF NOT EXISTS digests_ai AFTER INSERT ON digests BEGIN
    INSERT INTO digests_fts(rowid, summary) VALUES (new.id, new.summary);
END;

CREATE TRIGGER IF NOT EXISTS digests_ad AFTER DELETE ON digests BEGIN
    INSERT INTO digests_fts(digests_fts, rowid, summary) VALUES ('delete', old.id, old.summary);
END;

CREATE TRIGGER IF NOT EXISTS digests_au AFTER UPDATE OF summary ON digests BEGIN
    INSERT INTO digests_fts(digests_fts, rowid, summary) VALUES ('delete', old.id, old.summary);
    INSERT INTO digests_fts(rowid, summary) VALUES (new.id, new.summary);
END;

CREATE TABLE IF NOT EXISTS import_state (
    path         TEXT PRIMARY KEY,
    size         INTEGER NOT NULL DEFAULT 0,
    mtime        REAL NOT NULL DEFAULT 0,
    offset       INTEGER NOT NULL DEFAULT 0,
    line_no      INTEGER NOT NULL DEFAULT 0,
    turn_counter INTEGER NOT NULL DEFAULT 0,
    session_id   TEXT,
    fingerprint  TEXT,
    updated_at   TEXT
);

-- UUIDs that were in the model context when a compaction happened.
-- preserved=1 means the message survived; 0 means it was summarized away.
CREATE TABLE IF NOT EXISTS compaction_drops (
    event_id   INTEGER NOT NULL,
    uuid       TEXT NOT NULL,
    preserved  INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (event_id, uuid)
);

CREATE INDEX IF NOT EXISTS idx_drops_uuid ON compaction_drops(uuid);
CREATE INDEX IF NOT EXISTS idx_drops_event ON compaction_drops(event_id);

CREATE TABLE IF NOT EXISTS meta_kv (
    key   TEXT PRIMARY KEY,
    value TEXT
);

-- Local embedding vectors (fastembed / bge-small-zh). Vectors are L2-normalized
-- float32 arrays stored as BLOBs, keyed by event id or digest id.
CREATE TABLE IF NOT EXISTS vectors (
    kind         TEXT NOT NULL,          -- 'event' | 'digest'
    ref_id       INTEGER NOT NULL,
    model        TEXT NOT NULL,
    dim          INTEGER NOT NULL,
    content_hash TEXT NOT NULL,
    vec          BLOB NOT NULL,
    updated_at   TEXT,
    PRIMARY KEY (kind, ref_id)
);

CREATE INDEX IF NOT EXISTS idx_vectors_model ON vectors(model);

-- Chunked vectors: one row per sentence-sized chunk. Retrieval takes the best
-- chunk per (kind, ref_id).
CREATE TABLE IF NOT EXISTS vector_chunks (
    kind         TEXT NOT NULL,
    ref_id       INTEGER NOT NULL,
    chunk_idx    INTEGER NOT NULL,
    model        TEXT NOT NULL,
    dim          INTEGER NOT NULL,
    group_hash   TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    vec          BLOB NOT NULL,
    updated_at   TEXT,
    PRIMARY KEY (kind, ref_id, chunk_idx)
);

CREATE INDEX IF NOT EXISTS idx_vector_chunks_model ON vector_chunks(model);
CREATE INDEX IF NOT EXISTS idx_vector_chunks_ref ON vector_chunks(kind, ref_id);
"""


def connect(db_path: str, init: bool = True) -> sqlite3.Connection:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=10000")
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA foreign_keys=ON")
    if init:
        init_schema(conn)
    return conn


DIGEST_MIGRATIONS = {
    "summary_det": "TEXT",
    "llm_summary": "TEXT",
    "decisions": "TEXT",
    "open_questions": "TEXT",
    "llm_model": "TEXT",
    "llm_updated_at": "TEXT",
}


def _migrate(conn: sqlite3.Connection) -> None:
    """Add columns introduced after v1 without rebuilding the 430MB database."""
    columns = {row[1] for row in conn.execute("PRAGMA table_info(digests)")}
    for name, ddl in DIGEST_MIGRATIONS.items():
        if name not in columns:
            conn.execute(f"ALTER TABLE digests ADD COLUMN {name} {ddl}")

    import_columns = {row[1] for row in conn.execute("PRAGMA table_info(import_state)")}
    if "fingerprint" not in import_columns:
        conn.execute("ALTER TABLE import_state ADD COLUMN fingerprint TEXT")


def init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    _migrate(conn)
    conn.commit()


def rebuild_fts(conn: sqlite3.Connection) -> None:
    conn.execute("INSERT INTO events_fts(events_fts) VALUES ('rebuild')")
    conn.execute("INSERT INTO digests_fts(digests_fts) VALUES ('rebuild')")
    conn.commit()


def db_stats(conn: sqlite3.Connection) -> dict:
    def one(sql: str, params=()):
        return conn.execute(sql, params).fetchone()[0]

    return {
        "events": one("SELECT COUNT(*) FROM events"),
        "turns": one("SELECT COUNT(*) FROM digests"),
        "sessions": one("SELECT COUNT(DISTINCT session_id) FROM events WHERE session_id IS NOT NULL"),
        "notes": one("SELECT COUNT(*) FROM events WHERE kind='note'"),
        "checkpoints": one("SELECT COUNT(*) FROM events WHERE kind='checkpoint'"),
        "compactions": one("SELECT COUNT(*) FROM events WHERE kind='compact_boundary'"),
        "llm_summaries": one(
            "SELECT COUNT(*) FROM digests WHERE llm_summary IS NOT NULL AND llm_summary != ''"
        ),
        "vectors": one(
            "SELECT COUNT(DISTINCT kind || ':' || ref_id) FROM vector_chunks"
        ),
        "vector_chunks": one("SELECT COUNT(*) FROM vector_chunks"),
        "first_ts": one("SELECT MIN(ts) FROM events"),
        "last_ts": one("SELECT MAX(ts) FROM events"),
        "db_bytes": one("PRAGMA page_count") * one("PRAGMA page_size"),
    }
