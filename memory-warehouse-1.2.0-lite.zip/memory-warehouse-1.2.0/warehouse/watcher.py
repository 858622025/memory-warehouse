"""Agent-agnostic transcript watcher.

MCP has no standard "turn ended" / "before compaction" events. The practical
alternative is to keep a long-lived watcher running alongside the MCP server:
it polls the configured transcript roots, imports new bytes, and lets
sync_transcript's rewrite detection handle compaction rewrites.

This module works both as a background thread inside `mw.py mcp` and as a
standalone `mw.py watch` process. It never replaces the Claude Code hooks;
those remain the precise, event-driven path.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .config import ROOT
from .db import connect
from .importer import discover_transcripts, sync_transcript
from .textutil import json_compact, now_iso

LOG_PATH = ROOT / "logs" / "watcher.log"
MAX_LOG_BYTES = 2 * 1024 * 1024


def _log(message: str) -> None:
    try:
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        if LOG_PATH.exists() and LOG_PATH.stat().st_size > MAX_LOG_BYTES:
            backup = LOG_PATH.with_suffix(".log.1")
            try:
                if backup.exists():
                    backup.unlink()
                LOG_PATH.replace(backup)
            except OSError:
                pass
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_PATH, "a", encoding="utf-8") as handle:
            handle.write(f"{stamp} {message}\n")
    except Exception:
        pass


def read_watcher_stats(conn: sqlite3.Connection) -> dict:
    try:
        row = conn.execute(
            "SELECT value FROM meta_kv WHERE key = 'watcher_stats'"
        ).fetchone()
        if row and row[0]:
            data = json.loads(row[0])
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}


class TranscriptWatcher:
    def __init__(
        self,
        cfg: dict,
        *,
        interval: float | None = None,
        roots: list[str] | None = None,
        auto_embed: bool | None = None,
        auto_summarize: bool | None = None,
        verbose: bool = False,
    ):
        watcher_cfg = cfg.get("watcher") or {}
        self.cfg = cfg
        self.interval = float(
            interval if interval is not None else watcher_cfg.get("interval", 5)
        )
        self.roots = list(
            roots
            or watcher_cfg.get("roots")
            or cfg.get("transcript_roots")
            or []
        )
        self.auto_embed = (
            bool(watcher_cfg.get("auto_embed", True))
            if auto_embed is None
            else bool(auto_embed)
        )
        self.auto_summarize = (
            bool(watcher_cfg.get("auto_summarize", False))
            if auto_summarize is None
            else bool(auto_summarize)
        )
        self.summarize_after = int(watcher_cfg.get("summarize_after_seconds", 90))
        self.max_summaries = int(watcher_cfg.get("max_summaries_per_poll", 2))
        self.embed_min_interval = float(watcher_cfg.get("embed_min_interval", 30))
        self.verbose = verbose
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._conn: sqlite3.Connection | None = None
        self._owned_conn = False
        self._lock = threading.Lock()
        self._last_embed = 0.0
        self._last_summary_event_id: int | None = None
        self.stats: dict = {
            "running": False,
            "interval": self.interval,
            "roots": self.roots,
            "last_poll": None,
            "files": 0,
            "imported": 0,
            "rewrites": 0,
            "embedded": 0,
            "summaries": 0,
            "errors": 0,
            "last_error": None,
            "poll_imported": 0,
            "poll_rewrites": 0,
            "poll_embedded": 0,
            "poll_summaries": 0,
            "poll_errors": 0,
        }

    # ------------------------------------------------------------------
    # lifecycle
    # ------------------------------------------------------------------

    def start(self) -> "TranscriptWatcher":
        if self._thread and self._thread.is_alive():
            return self
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="memory-warehouse-watcher", daemon=True
        )
        self._thread.start()
        return self

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=timeout)
        self.stats["running"] = False

    def _open(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = connect(self.cfg["db_path"])
            self._owned_conn = True
        return self._conn

    def _close(self) -> None:
        if self._owned_conn and self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
        self._conn = None
        self._owned_conn = False

    def _restore_stats(self, conn: sqlite3.Connection) -> None:
        stored = read_watcher_stats(conn)
        if stored:
            self.stats.update(
                {key: value for key, value in stored.items() if key != "running"}
            )

    def _run(self) -> None:
        conn = self._open()
        self._restore_stats(conn)
        try:
            if self._last_summary_event_id is None:
                row = conn.execute("SELECT COALESCE(MAX(id), 0) FROM events").fetchone()
                self._last_summary_event_id = int(row[0] or 0)
            self.stats["running"] = True
            while not self._stop.is_set():
                try:
                    self.run_once(conn=conn)
                except Exception:
                    self.stats["errors"] += 1
                    self.stats["last_error"] = traceback.format_exc()
                    _log("poll failed:\n" + traceback.format_exc())
                self._stop.wait(self.interval)
        finally:
            self.stats["running"] = False
            self._close()

    def run_forever(self) -> None:
        """Blocking loop for `mw.py watch`."""
        conn = self._open()
        self._restore_stats(conn)
        try:
            if self._last_summary_event_id is None:
                row = conn.execute("SELECT COALESCE(MAX(id), 0) FROM events").fetchone()
                self._last_summary_event_id = int(row[0] or 0)
            self.stats["running"] = True
            while not self._stop.is_set():
                stats = self.run_once(conn=conn)
                if self.verbose:
                    print(
                        f"[{stats['last_poll']}] files={stats['files']} "
                        f"imported={stats['imported']} "
                        f"rewrites={stats['rewrites']} "
                        f"embedded={stats['embedded']} "
                        f"summaries={stats['summaries']}"
                    )
                self._stop.wait(self.interval)
        finally:
            self.stats["running"] = False
            self._close()

    # ------------------------------------------------------------------
    # one poll
    # ------------------------------------------------------------------

    def run_once(
        self, force: bool = False, conn: sqlite3.Connection | None = None
    ) -> dict:
        with self._lock:
            owned = conn is None
            conn = conn or connect(self.cfg["db_path"])
            if self.stats.get("last_poll") is None:
                self._restore_stats(conn)
            paths = discover_transcripts(self.roots)
            imported = 0
            rewrites = 0
            errors = 0
            last_error = None

            for path in paths:
                try:
                    result = sync_transcript(conn, path, self.cfg, verbose=False)
                except Exception:
                    errors += 1
                    last_error = traceback.format_exc()
                    _log(f"sync failed for {path}:\n{last_error}")
                    continue
                imported += int(result.get("imported") or 0)
                if result.get("rewritten"):
                    rewrites += 1
                    _log(
                        f"transcript rewritten: {path} "
                        f"(old offset {result.get('old_offset')} → {result.get('offset')})"
                    )

            embedded = 0
            summaries = 0
            if imported and self.auto_embed:
                now = time.time()
                if force or now - self._last_embed >= self.embed_min_interval:
                    try:
                        from .vectors import build_vectors

                        embed_result = build_vectors(
                            conn, self.cfg, force=False, verbose=False
                        )
                        embedded = int(embed_result.get("embedded") or 0)
                        self._last_embed = now
                    except Exception:
                        errors += 1
                        last_error = traceback.format_exc()
                        _log("auto-embed failed:\n" + last_error)

            if self.auto_summarize:
                try:
                    summaries = self._summarize_new_turns(conn)
                except Exception:
                    errors += 1
                    last_error = traceback.format_exc()
                    _log("auto-summarize failed:\n" + last_error)

            self.stats.update(
                {
                    "running": self.stats.get("running", False),
                    "interval": self.interval,
                    "roots": self.roots,
                    "last_poll": now_iso(),
                    "files": len(paths),
                    "imported": self.stats.get("imported", 0) + imported,
                    "rewrites": self.stats.get("rewrites", 0) + rewrites,
                    "embedded": self.stats.get("embedded", 0) + embedded,
                    "summaries": self.stats.get("summaries", 0) + summaries,
                    "errors": self.stats.get("errors", 0) + errors,
                    "last_error": last_error or self.stats.get("last_error"),
                    "poll_imported": imported,
                    "poll_rewrites": rewrites,
                    "poll_embedded": embedded,
                    "poll_summaries": summaries,
                    "poll_errors": errors,
                }
            )
            try:
                conn.execute(
                    """
                    INSERT INTO meta_kv(key, value) VALUES ('watcher_stats', ?)
                    ON CONFLICT(key) DO UPDATE SET value=excluded.value
                    """,
                    (json_compact(self.stats),),
                )
                conn.commit()
            except Exception:
                pass
            if owned:
                try:
                    conn.close()
                except Exception:
                    pass
            return dict(self.stats)

    def _summarize_new_turns(self, conn: sqlite3.Connection) -> int:
        if self._last_summary_event_id is None:
            row = conn.execute("SELECT COALESCE(MAX(id), 0) FROM events").fetchone()
            self._last_summary_event_id = int(row[0] or 0)
            return 0
        cutoff = (
            datetime.now(timezone.utc) - timedelta(seconds=self.summarize_after)
        ).strftime("%Y-%m-%dT%H:%M:%S")
        rows = conn.execute(
            """
            SELECT session_id, turn_index, event_end
            FROM digests
            WHERE (llm_updated_at IS NULL OR llm_updated_at = '')
              AND event_end > ?
              AND COALESCE(ended_at, started_at) < ?
            ORDER BY event_end ASC
            LIMIT ?
            """,
            (self._last_summary_event_id, cutoff, self.max_summaries),
        ).fetchall()
        if not rows:
            return 0
        from .llm import summarize_turn

        done = 0
        for row in rows:
            try:
                result = summarize_turn(
                    conn,
                    self.cfg,
                    row["session_id"],
                    int(row["turn_index"]),
                )
                if not result.get("skipped"):
                    done += 1
            except Exception:
                _log("summarize turn failed:\n" + traceback.format_exc())
            self._last_summary_event_id = max(
                self._last_summary_event_id, int(row["event_end"] or 0)
            )
        return done

    # ------------------------------------------------------------------
    # introspection
    # ------------------------------------------------------------------

    def status(self) -> dict:
        data = dict(self.stats)
        data["running"] = bool(
            (self._thread and self._thread.is_alive())
            or data.get("running")
        )
        return data
