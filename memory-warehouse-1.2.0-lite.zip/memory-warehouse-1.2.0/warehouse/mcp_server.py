from __future__ import annotations

import json
import os
import sys
import traceback

from . import __version__
from .brief import build_brief
from .db import connect, db_stats
from .importer import sync_transcript
from .llm import llm_status, summarize_many, summarize_turn
from .search import format_results, search
from .textutil import json_compact, now_iso, parse_since
from .cli import _insert_manual_event
from .vectors import build_vectors, vector_stats
from .watcher import TranscriptWatcher, read_watcher_stats

SERVER_INFO = {"name": "memory-warehouse", "version": __version__}
PROTOCOL_VERSION = "2025-06-18"

TOOLS = [
    {
        "name": "recall",
        "description": (
            "Search the local conversation memory warehouse (SQLite FTS5). "
            "Use this to recover details that fell out of context after compaction."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Keywords or a phrase"},
                "limit": {"type": "integer", "default": 8},
                "cwd": {"type": "string", "description": "Filter by project directory"},
                "session": {"type": "string", "description": "Session id prefix"},
                "kind": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "prompt/text/tool_use/tool_result/note/checkpoint/digest",
                },
                "since": {"type": "string", "description": "7d, 24h, or an ISO date"},
                "any": {"type": "boolean", "description": "Match any term instead of all"},
                "semantic": {
                    "type": "boolean",
                    "description": "Use local vector retrieval fused with BM25 (default: auto)",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "summarize",
        "description": (
            "Generate LLM semantic summaries for turns (decisions, open questions, "
            "must-keep identifiers). Runs against the configured model."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "session": {"type": "string", "description": "Session id prefix"},
                "turn": {"type": "integer", "description": "Specific turn index"},
                "limit": {"type": "integer", "default": 10},
                "force": {"type": "boolean", "default": False},
            },
        },
    },
    {
        "name": "embed",
        "description": "Build/update the local vector index used for semantic recall.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "default": 0},
                "force": {"type": "boolean", "default": False},
            },
        },
    },
    {
        "name": "remember",
        "description": "Store a durable note in the memory warehouse. Set pinned=true to inject it into future session briefs.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
                "pinned": {"type": "boolean", "default": False},
                "cwd": {"type": "string"},
            },
            "required": ["text"],
        },
    },
    {
        "name": "checkpoint",
        "description": "Write a structured checkpoint (what to keep if context is compacted).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "must_keep": {"type": "array", "items": {"type": "string"}},
                "cwd": {"type": "string"},
            },
            "required": ["summary"],
        },
    },
    {
        "name": "brief",
        "description": "Return the memory brief that is injected at the start of a session.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "cwd": {"type": "string"},
                "max_chars": {"type": "integer"},
            },
        },
    },
    {
        "name": "sync",
        "description": (
            "Scan the configured transcript roots once and import new events. "
            "This is the MCP alternative to hooks when the client cannot run them."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "watch_status",
        "description": "Return the transcript watcher status (last poll, imports, rewrites).",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "ingest",
        "description": "Import one specific transcript file by path.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Absolute transcript path"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "stats",
        "description": "Memory warehouse statistics.",
        "inputSchema": {"type": "object", "properties": {}},
    },
]


class Server:
    def __init__(self, cfg: dict, watch: bool = True):
        self.cfg = cfg
        self.conn = connect(cfg["db_path"])
        self.watcher = TranscriptWatcher(cfg)
        if watch and (cfg.get("watcher") or {}).get("enabled", True):
            self.watcher.start()

    def _text(self, text: str, is_error: bool = False) -> dict:
        return {
            "content": [{"type": "text", "text": text}],
            "isError": bool(is_error),
        }

    def call_tool(self, name: str, args: dict) -> dict:
        if name == "recall":
            semantic = args.get("semantic")
            results = search(
                self.conn,
                str(args.get("query") or ""),
                cfg=self.cfg,
                semantic=bool(semantic) if semantic is not None else None,
                limit=int(args.get("limit") or 8),
                cwd=args.get("cwd"),
                session=args.get("session"),
                kinds=args.get("kind") or None,
                since=parse_since(args.get("since")),
                any_terms=bool(args.get("any")),
            )
            return self._text(format_results(results))
        if name == "summarize":
            if args.get("session") and args.get("turn") is not None:
                session = str(args["session"])
                row = self.conn.execute(
                    "SELECT session_id FROM digests WHERE session_id LIKE ? ORDER BY id DESC LIMIT 1",
                    (f"{session}%",),
                ).fetchone()
                if row:
                    session = row["session_id"]
                result = summarize_turn(
                    self.conn,
                    self.cfg,
                    session,
                    int(args["turn"]),
                    force=bool(args.get("force")),
                )
            else:
                result = summarize_many(
                    self.conn,
                    self.cfg,
                    limit=int(args.get("limit") or 10),
                    force=bool(args.get("force")),
                    session=args.get("session"),
                    verbose=False,
                )
            return self._text(json.dumps(result, ensure_ascii=False, indent=2))
        if name == "embed":
            result = build_vectors(
                self.conn,
                self.cfg,
                force=bool(args.get("force")),
                limit=int(args.get("limit") or 0) or None,
                verbose=False,
            )
            return self._text(json.dumps(result, ensure_ascii=False, indent=2))
        if name == "remember":
            event_id = _insert_manual_event(
                self.conn,
                self.cfg,
                kind="note",
                text=str(args.get("text") or ""),
                cwd=args.get("cwd"),
                pinned=bool(args.get("pinned")),
                tags=list(args.get("tags") or []),
            )
            return self._text(f"stored note id={event_id}")
        if name == "checkpoint":
            text = str(args.get("summary") or "")
            must_keep = [str(item) for item in (args.get("must_keep") or [])]
            if must_keep:
                text += "\n关键标识：" + "; ".join(must_keep)
            event_id = _insert_manual_event(
                self.conn,
                self.cfg,
                kind="checkpoint",
                text=text,
                cwd=args.get("cwd"),
                pinned=False,
                tags=["checkpoint", "mcp"],
                meta={"trigger": "mcp", "must_keep": must_keep},
            )
            return self._text(f"stored checkpoint id={event_id}")
        if name == "brief":
            text = build_brief(
                self.conn,
                self.cfg,
                cwd=args.get("cwd") or os.getcwd(),
                max_chars=args.get("max_chars"),
            )
            return self._text(text)
        if name == "sync":
            result = self.watcher.run_once(force=True)
            return self._text(json.dumps(result, ensure_ascii=False, indent=2))
        if name == "watch_status":
            data = self.watcher.status()
            stored = read_watcher_stats(self.conn)
            if stored:
                merged = dict(stored)
                # The watcher thread restores the heartbeat asynchronously. If
                # it has not polled yet, prefer the stored cumulative counters
                # instead of overwriting them with zeroes.
                if data.get("last_poll") is not None:
                    merged.update(
                        {key: value for key, value in data.items() if value is not None}
                    )
                merged["running"] = bool(data.get("running"))
                data = merged
            return self._text(json.dumps(data, ensure_ascii=False, indent=2))
        if name == "ingest":
            path = str(args.get("path") or "")
            if not path or not os.path.exists(path):
                return self._text(f"transcript not found: {path}", is_error=True)
            result = sync_transcript(self.conn, path, self.cfg)
            return self._text(json.dumps(result, ensure_ascii=False, indent=2))
        if name == "stats":
            stats = db_stats(self.conn)
            stats["llm"] = llm_status(self.cfg)
            stats["vector_index"] = vector_stats(self.conn)
            stats["watcher"] = self.watcher.status()
            return self._text(json.dumps(stats, ensure_ascii=False, indent=2))
        return self._text(f"unknown tool: {name}", is_error=True)

    def handle(self, message: dict) -> dict | None:
        method = message.get("method")
        request_id = message.get("id")
        params = message.get("params") or {}

        if method == "initialize":
            result = {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {
                    "tools": {"listChanged": False},
                    "resources": {"subscribe": False, "listChanged": False},
                },
                "serverInfo": SERVER_INFO,
                "instructions": (
                    "Local memory warehouse. A background watcher imports configured "
                    "transcripts. Call recall before saying you cannot remember earlier "
                    "details; call sync if the watcher is disabled."
                ),
            }
            return {"jsonrpc": "2.0", "id": request_id, "result": result}
        if method == "notifications/initialized":
            return None
        if method == "ping":
            return {"jsonrpc": "2.0", "id": request_id, "result": {}}
        if method == "tools/list":
            return {"jsonrpc": "2.0", "id": request_id, "result": {"tools": TOOLS}}
        if method == "resources/list":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "resources": [
                        {
                            "uri": "memory://brief",
                            "name": "Memory brief",
                            "mimeType": "text/markdown",
                            "description": "Recent progress, checkpoints, and last compaction summary",
                        },
                        {
                            "uri": "memory://stats",
                            "name": "Memory stats",
                            "mimeType": "application/json",
                            "description": "Warehouse event/turn/vector statistics",
                        },
                    ]
                },
            }
        if method == "resources/read":
            uri = params.get("uri")
            if uri == "memory://brief":
                text = build_brief(self.conn, self.cfg, cwd=os.getcwd())
                mime = "text/markdown"
            elif uri == "memory://stats":
                data = db_stats(self.conn)
                data["vector_index"] = vector_stats(self.conn)
                data["llm"] = llm_status(self.cfg)
                text = json.dumps(data, ensure_ascii=False, indent=2)
                mime = "application/json"
            else:
                return {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {"code": -32602, "message": f"unknown resource: {uri}"},
                }
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "contents": [{"uri": uri, "mimeType": mime, "text": text}]
                },
            }
        if method == "tools/call":
            name = params.get("name")
            args = params.get("arguments") or {}
            try:
                result = self.call_tool(str(name), args)
            except Exception:
                result = self._text(traceback.format_exc(), is_error=True)
            return {"jsonrpc": "2.0", "id": request_id, "result": result}
        if request_id is None:
            return None
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32601, "message": f"method not found: {method}"},
        }


def serve(cfg: dict, watch: bool = True) -> int:
    server = Server(cfg, watch=watch)
    out = sys.stdout
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stdin.reconfigure(encoding="utf-8")
    except Exception:
        pass
    try:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                message = json.loads(line)
            except Exception:
                continue
            try:
                response = server.handle(message)
            except Exception:
                response = {
                    "jsonrpc": "2.0",
                    "id": message.get("id"),
                    "error": {"code": -32603, "message": traceback.format_exc()},
                }
            if response is not None:
                out.write(json.dumps(response, ensure_ascii=False) + "\n")
                out.flush()
    finally:
        server.watcher.stop()
        try:
            server.conn.close()
        except Exception:
            pass
    return 0
