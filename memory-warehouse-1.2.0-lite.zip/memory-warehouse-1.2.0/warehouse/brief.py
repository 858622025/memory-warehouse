from __future__ import annotations

import sqlite3

from .config import ROOT
from .db import db_stats
from .textutil import clip, normalize_cwd, project_label, safe_json_loads

MW_ENTRY = f'python "{ROOT / "mw.py"}"'


def _digest_line(row: dict, project: bool = False) -> str:
    ts = (row.get("ended_at") or row.get("started_at") or "")[:16].replace("T", " ")
    summary = " · ".join((row.get("summary") or "").splitlines())
    label = f"[{project_label(row.get('cwd'))}] " if project else ""
    return f"- {ts} {label}{clip(summary, 280)}"


def _recent_digests(conn: sqlite3.Connection, cwd: str | None, limit: int) -> tuple[list[dict], bool]:
    """Return digests for this cwd; if too few, top up with other projects."""
    rows: list[dict] = []
    cwd = normalize_cwd(cwd)
    if cwd:
        rows = [
            dict(row)
            for row in conn.execute(
                """
                SELECT * FROM digests
                WHERE cwd = ? COLLATE NOCASE
                ORDER BY COALESCE(ended_at, started_at) DESC
                LIMIT ?
                """,
                (cwd, limit),
            ).fetchall()
        ]
    if len(rows) < limit:
        seen = {(row["session_id"], row["turn_index"]) for row in rows}
        extra = conn.execute(
            """
            SELECT * FROM digests
            ORDER BY COALESCE(ended_at, started_at) DESC
            LIMIT ?
            """,
            (limit * 3,),
        ).fetchall()
        for row in extra:
            key = (row["session_id"], row["turn_index"])
            if key in seen:
                continue
            rows.append(dict(row))
            seen.add(key)
            if len(rows) >= limit:
                break
        return rows, True
    return rows, False


def _recent_checkpoints(conn: sqlite3.Connection, cwd: str | None, limit: int) -> list[dict]:
    cwd = normalize_cwd(cwd)
    if cwd:
        rows = conn.execute(
            """
            SELECT * FROM events
            WHERE kind = 'checkpoint' AND (cwd = ? COLLATE NOCASE OR cwd IS NULL)
            ORDER BY id DESC LIMIT ?
            """,
            (cwd, limit * 3),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM events WHERE kind = 'checkpoint' ORDER BY id DESC LIMIT ?",
            (limit * 3,),
        ).fetchall()
    return [dict(row) for row in rows[:limit]]


def _last_compaction(conn: sqlite3.Connection, cwd: str | None) -> dict | None:
    cwd = normalize_cwd(cwd)
    if cwd:
        row = conn.execute(
            """
            SELECT * FROM events
            WHERE kind = 'compaction_summary' AND (cwd = ? COLLATE NOCASE OR cwd IS NULL)
            ORDER BY id DESC LIMIT 1
            """,
            (cwd,),
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT * FROM events WHERE kind = 'compaction_summary' ORDER BY id DESC LIMIT 1"
        ).fetchone()
    return dict(row) if row else None


def _pinned(conn: sqlite3.Connection, limit: int) -> list[dict]:
    rows = conn.execute(
        """
        SELECT * FROM events
        WHERE pinned = 1 AND kind IN ('note', 'checkpoint')
        ORDER BY id DESC LIMIT ?
        """,
        (limit,),
    ).fetchall()
    return [dict(row) for row in rows]


def build_brief(
    conn: sqlite3.Connection,
    cfg: dict,
    cwd: str | None = None,
    source: str | None = None,
    max_chars: int | None = None,
) -> str:
    limit_chars = int(max_chars or cfg.get("brief_max_chars") or 3500)
    cwd = normalize_cwd(cwd)
    stats = db_stats(conn)
    digest_limit = int(cfg.get("brief_recent_digests") or 6)
    checkpoint_limit = int(cfg.get("brief_checkpoints") or 2)

    sections: list[tuple[str, list[str]]] = []

    header = [
        f"# 记忆仓库 · {project_label(cwd) if cwd else '全局'}",
        f"已索引 {stats['events']:,} 条事件 · {stats['turns']:,} 个回合 · "
        f"{stats['sessions']:,} 个会话 · {stats['compactions']} 次上下文压缩。",
    ]
    if source == "compact":
        header.append("⚠ 本会话刚经历过上下文压缩。以下快照来自压缩前的本地索引。")
    elif source == "clear":
        header.append("（本会话是 /clear 后新开的，以下是历史记忆。）")
    sections.append(("", header))

    pinned = _pinned(conn, 8)
    if pinned:
        sections.append(
            (
                "## 固定记忆",
                [
                    f"- {clip(row['content'], 240)}"
                    for row in pinned
                ],
            )
        )

    checkpoints = _recent_checkpoints(conn, cwd, checkpoint_limit)
    if checkpoints:
        lines: list[str] = []
        for row in checkpoints:
            meta = safe_json_loads(row.get("meta")) or {}
            ts = (row.get("ts") or "")[:16].replace("T", " ")
            trigger = meta.get("trigger") or "manual"
            lines.append(f"- [{ts}] 检查点（{trigger}）")
            body = " · ".join((row.get("content") or "").splitlines())
            lines.append(f"  {clip(body, 620)}")
            must_keep = meta.get("must_keep") or []
            if must_keep:
                lines.append("  关键词：" + "; ".join(clip(str(x), 70) for x in must_keep[:8]))
        sections.append(("## 最近检查点", lines))

    digests, mixed = _recent_digests(conn, cwd, digest_limit)
    if digests:
        title = "## 最近进展" if not mixed else "## 最近进展（含其他项目）"
        sections.append((title, [_digest_line(row, project=mixed) for row in digests]))

    compaction = _last_compaction(conn, cwd)
    if compaction:
        body = " ".join((compaction.get("content") or "").split())
        ts = (compaction.get("ts") or "")[:16].replace("T", " ")
        sections.append(
            (
                "## 上次压缩摘要",
                [f"（{ts}）{clip(body, 1100)}"],
            )
        )

    hint = (
        f"需要更早的细节：`{MW_ENTRY} recall \"关键词\" --since 90d`；"
        f"`{MW_ENTRY} timeline` 看时间线。"
    )
    sections.append(("", [hint]))

    output: list[str] = []
    used = 0
    stopped = False
    for title, lines in sections:
        block_parts = ([title] if title else []) + lines
        block = "\n".join(block_parts)
        remaining = limit_chars - used
        if remaining <= 20:
            stopped = True
            break
        if len(block) <= remaining:
            output.append(block)
            used += len(block) + 2
        else:
            output.append(block[: remaining - 16] + "\n…（记忆摘要已截断）")
            stopped = True
            break
    if stopped:
        pass
    return "\n\n".join(output).strip()
