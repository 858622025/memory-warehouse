from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Redaction
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\bsk-[A-Za-z0-9_\-]{16,}\b"), "[REDACTED_KEY]"),
    (re.compile(r"\bghp_[A-Za-z0-9]{20,}\b"), "[REDACTED_KEY]"),
    (re.compile(r"\bgithub_pat_[A-Za-z0-9_]{20,}\b"), "[REDACTED_KEY]"),
    (re.compile(r"\bxox[baprs]-[A-Za-z0-9\-]{10,}\b"), "[REDACTED_KEY]"),
    (re.compile(r"(?i)\b(Bearer\s+)[A-Za-z0-9\-._~+/]+=*"), r"\1[REDACTED]"),
    (
        re.compile(
            r"(?i)\b(api[_-]?key|access[_-]?token|auth[_-]?token|secret|password|passwd|pwd)"
            r"(\s*[:=]\s*)([\"']?)([^\s\"',;]{6,})"
        ),
        r"\1\2\3[REDACTED]",
    ),
]


def redact(text: str) -> str:
    if not text:
        return text
    for pattern, replacement in _SECRET_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


# ---------------------------------------------------------------------------
# Truncation / formatting
# ---------------------------------------------------------------------------


def cap_text(text: str, limit: int) -> tuple[str, bool, int]:
    """Return (capped_text, truncated, original_length)."""
    text = text or ""
    original = len(text)
    if limit <= 0 or original <= limit:
        return text, False, original
    return (
        text[:limit] + f"\n…[truncated {original - limit} chars; use `show <id>` for full]",
        True,
        original,
    )


def clip(text: str, limit: int) -> str:
    text = " ".join((text or "").split())
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 1)] + "…"


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def parse_since(value: str | None) -> str | None:
    """Accept '7d', '24h', '30m', or an ISO date. Returns an ISO timestamp."""
    if not value:
        return None
    value = value.strip()
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([dhm])", value, re.IGNORECASE)
    if match:
        amount = float(match.group(1))
        unit = match.group(2).lower()
        seconds = {"d": 86400, "h": 3600, "m": 60}[unit] * amount
        from datetime import timedelta

        dt = datetime.now(timezone.utc) - timedelta(seconds=seconds)
        return dt.strftime("%Y-%m-%dT%H:%M:%S")
    dt = parse_iso(value)
    if dt is None:
        try:
            dt = datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except Exception:
            return None
    return dt.strftime("%Y-%m-%dT%H:%M:%S")


def normalize_cwd(value: str | None) -> str | None:
    """Hooks may report C:/x/y while transcripts store C:\\x\\y. Unify them."""
    if not value:
        return value
    try:
        import os

        return os.path.normpath(value)
    except Exception:
        return value


def short_path(path: str | None, parts: int = 2) -> str:
    if not path:
        return ""
    p = Path(path)
    bits = list(p.parts)
    if len(bits) <= parts:
        return str(p)
    return "…/" + "/".join(bits[-parts:])


def project_label(cwd: str | None) -> str:
    if not cwd:
        return "?"
    name = Path(cwd).name
    return name or cwd


def is_cjk(text: str) -> bool:
    return any("㐀" <= ch <= "鿿" or "豈" <= ch <= "﫿" for ch in text)


def json_compact(value) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)


def safe_json_loads(value: str | None):
    if not value:
        return None
    try:
        return json.loads(value)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Tool input analysis
# ---------------------------------------------------------------------------


def extract_refs(tool_input) -> dict[str, list[str]]:
    """Collect file paths, commands, urls, patterns from a tool input object."""
    files: list[str] = []
    commands: list[str] = []
    urls: list[str] = []
    patterns: list[str] = []

    def add(bucket: list[str], value: str) -> None:
        value = value.strip()
        if value and value not in bucket:
            bucket.append(value)

    def walk(obj) -> None:
        if isinstance(obj, dict):
            for key, value in obj.items():
                if isinstance(value, str):
                    lk = key.lower()
                    if lk in {"file_path", "notebook_path"}:
                        add(files, value)
                    elif lk == "path" and ("/" in value or "\\" in value):
                        add(files, value)
                    elif lk in {"files", "file_paths"}:
                        add(files, value)
                    elif lk == "command":
                        add(commands, value)
                    elif lk in {"url", "uri"}:
                        add(urls, value)
                    elif lk in {"pattern", "glob"}:
                        add(patterns, value)
                else:
                    walk(value)
        elif isinstance(obj, (list, tuple)):
            for item in obj:
                walk(item)

    if tool_input is not None:
        walk(tool_input)
    return {
        "files": files[:24],
        "commands": commands[:16],
        "urls": urls[:8],
        "patterns": patterns[:8],
    }


def format_tool_use(name: str, tool_input) -> str:
    if not isinstance(tool_input, dict):
        return f"{name}: {tool_input}"
    lower = (name or "").lower()
    if lower == "bash":
        command = str(tool_input.get("command", ""))
        description = tool_input.get("description")
        return f"$ {command}" + (f"  # {description}" if description else "")
    for key in ("file_path", "notebook_path", "path"):
        if isinstance(tool_input.get(key), str) and tool_input.get(key):
            return f"{name}: {tool_input[key]}"
    if lower in {"grep", "glob"}:
        return f"{name}: {tool_input.get('pattern', '')} {tool_input.get('path', '')}".strip()
    if tool_input.get("url"):
        return f"{name}: {tool_input['url']}"
    return f"{name}: {json_compact(tool_input)}"


def flatten_content(content) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                btype = block.get("type")
                if btype == "text":
                    parts.append(block.get("text", ""))
                elif btype == "image":
                    parts.append("[image]")
                elif btype == "thinking":
                    parts.append(block.get("thinking", ""))
                else:
                    parts.append(json_compact(block))
            else:
                parts.append(str(block))
        return "\n".join(p for p in parts if p)
    return json_compact(content)


# ---------------------------------------------------------------------------
# "Must keep" identifier extraction (for checkpoints)
# ---------------------------------------------------------------------------

_TRAILING = ".,;:，。；：、）)]\"'`"


def _clean_identifier(value: str) -> str:
    return value.strip().strip(_TRAILING).strip()


_STOP_CHARS = r"^\s\"'<>|*?\n\r，。；：、（）【】《》"
_MUST_KEEP_PATTERNS = [
    # Windows path; do not start inside "https:" and stop at CJK punctuation.
    re.compile(rf"(?<![A-Za-z0-9])[A-Za-z]:[\\/][{_STOP_CHARS}]+"),
    re.compile(
        rf"(?<![:/\w.])/(?:[{_STOP_CHARS}/]+/)+[{_STOP_CHARS}/]+"
    ),
    re.compile(rf"https?://[{_STOP_CHARS})\]]+"),
    re.compile(r"`[^`\n]{2,160}`"),
    re.compile(r"《[^》\n]{1,80}》"),
    re.compile(r"【[^】\n]{1,80}】"),
    re.compile(r"(?m)^.*(?:Error|Traceback|Exception|报错|失败|undefined|not found).*$"),
]


def extract_must_keep(text: str, limit: int = 32) -> list[str]:
    """Pull exact identifiers out of text. These are what summaries lose."""
    if not text:
        return []
    found: list[str] = []
    seen: set[str] = set()
    for pattern in _MUST_KEEP_PATTERNS:
        for match in pattern.findall(text):
            item = _clean_identifier(match if isinstance(match, str) else match[0])
            if not item or len(item) < 2 or len(item) > 240:
                continue
            key = item.lower()
            if key in seen:
                continue
            seen.add(key)
            found.append(item)

    # Drop fragments that are contained in a longer identifier (e.g. the
    # "/example.com/a" tail of "https://example.com/a").
    lowered = [item.lower() for item in found]
    filtered: list[str] = []
    for index, item in enumerate(found):
        key = lowered[index]
        if any(
            key != other and key in other
            for other in lowered
            if len(other) > len(key)
        ):
            continue
        filtered.append(item)
        if len(filtered) >= limit:
            break
    return filtered
