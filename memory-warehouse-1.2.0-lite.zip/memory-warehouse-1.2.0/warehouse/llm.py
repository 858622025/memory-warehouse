"""V2: semantic turn summaries via an Anthropic-compatible Messages API.

The endpoint is taken from config.json -> llm, falling back to the same
ANTHROPIC_* environment variables the agent runtime uses. Everything is
opt-in and failure-tolerant: deterministic digests remain the source of truth.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

from .config import ROOT
from .digest import compose_summary, rebuild_digest
from .textutil import clip, extract_must_keep, json_compact, now_iso, safe_json_loads

MAX_PROMPT_CHARS = 14000


def _parse_custom_headers(raw) -> dict[str, str]:
    if not raw:
        return {}
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items()}
    if not str(raw).strip():
        return {}
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return {str(k): str(v) for k, v in obj.items()}
    except Exception:
        pass
    headers: dict[str, str] = {}
    for line in raw.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            headers[key.strip()] = value.strip()
    return headers


def api_settings(cfg: dict, model: str | None = None) -> dict:
    llm_cfg = cfg.get("llm") or {}
    base = (llm_cfg.get("base_url") or os.environ.get("ANTHROPIC_BASE_URL") or "").rstrip("/")
    api_key = llm_cfg.get("api_key") or os.environ.get("ANTHROPIC_API_KEY") or ""
    auth_token = llm_cfg.get("auth_token") or os.environ.get("ANTHROPIC_AUTH_TOKEN") or ""
    chosen_model = (
        model
        or llm_cfg.get("model")
        or os.environ.get("ANTHROPIC_DEFAULT_HAIKU_MODEL")
        or os.environ.get("ANTHROPIC_MODEL")
        or "claude-haiku-4-5-20251001"
    )
    headers = {
        "content-type": "application/json",
        "anthropic-version": "2023-06-01",
    }
    if api_key:
        headers["x-api-key"] = api_key
    if auth_token:
        headers["authorization"] = f"Bearer {auth_token}"
    headers.update(
        _parse_custom_headers(
            llm_cfg.get("custom_headers")
            or os.environ.get("ANTHROPIC_CUSTOM_HEADERS")
        )
    )
    endpoint = base + ("/messages" if base.endswith("/v1") else "/v1/messages")
    return {
        "enabled": bool(llm_cfg.get("enabled", True)) and bool(base) and bool(api_key or auth_token),
        "base_url": base,
        "endpoint": endpoint,
        "model": chosen_model,
        "headers": headers,
        "timeout": int(llm_cfg.get("timeout", 60)),
        "max_tokens": int(llm_cfg.get("max_tokens", 2500)),
        "disable_thinking": bool(llm_cfg.get("disable_thinking", True)),
    }


def llm_status(cfg: dict) -> dict:
    settings = api_settings(cfg)
    return {
        "enabled": settings["enabled"],
        "endpoint": settings["endpoint"],
        "model": settings["model"],
        "has_credentials": bool(
            settings["headers"].get("x-api-key") or settings["headers"].get("authorization")
        ),
    }


def _extract_text(payload: dict) -> str:
    content = payload.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text") or "")
        return "\n".join(part for part in parts if part)
    return ""


def call_llm(prompt: str, cfg: dict, model: str | None = None, max_tokens: int | None = None) -> str:
    settings = api_settings(cfg, model=model)
    if not settings["enabled"]:
        raise RuntimeError("LLM is not configured (missing ANTHROPIC_BASE_URL / credentials)")
    try:
        import requests
    except ImportError as exc:  # pragma: no cover - requests is present on this machine
        raise RuntimeError("requests is required for LLM summaries") from exc

    body = {
        "model": settings["model"],
        "max_tokens": int(max_tokens or settings["max_tokens"]),
        "temperature": 0,
        "messages": [{"role": "user", "content": prompt}],
    }
    if settings.get("disable_thinking", True):
        body["thinking"] = {"type": "disabled"}
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            response = requests.post(
                settings["endpoint"],
                headers=settings["headers"],
                json=body,
                timeout=settings["timeout"],
            )
            if response.status_code in (429, 500, 502, 503, 504) and attempt == 0:
                time.sleep(2)
                continue
            if (
                response.status_code == 400
                and "thinking" in response.text.lower()
                and attempt == 0
            ):
                body.pop("thinking", None)
                continue
            if response.status_code >= 400:
                raise RuntimeError(
                    f"LLM HTTP {response.status_code}: {response.text[:300]}"
                )
            payload = response.json()
            text = _extract_text(payload)
            if not text:
                raise RuntimeError(f"LLM returned no text: {json_compact(payload)[:300]}")
            return text
        except Exception as exc:
            last_error = exc
            if attempt == 0:
                time.sleep(1)
    raise RuntimeError(f"LLM call failed: {last_error}")


def build_turn_payload(
    conn, session_id: str, turn_index: int, max_chars: int = MAX_PROMPT_CHARS
) -> str:
    rows = conn.execute(
        """
        SELECT kind, content, meta FROM events
        WHERE session_id = ? AND turn_index = ? AND is_sidechain = 0
          AND kind IN ('prompt', 'text', 'tool_use', 'tool_result', 'note', 'checkpoint')
        ORDER BY id
        """,
        (session_id, turn_index),
    ).fetchall()
    lines: list[str] = []
    total = 0
    for row in rows:
        kind = row["kind"]
        content = (row["content"] or "").strip()
        if not content:
            continue
        meta = safe_json_loads(row["meta"]) or {}
        if kind == "prompt":
            label = "用户"
        elif kind == "text":
            label = "助手"
        elif kind == "tool_use":
            label = f"工具调用({meta.get('tool_name') or 'tool'})"
        elif kind == "tool_result":
            label = "工具结果(报错)" if meta.get("is_error") else "工具结果"
        else:
            label = "笔记"
        if kind == "tool_result" and not meta.get("is_error"):
            content = content[:400]
        else:
            content = content[:2400]
        chunk = f"[{label}] {content}"
        if total + len(chunk) > max_chars:
            remaining = max_chars - total
            if remaining > 200:
                lines.append(chunk[:remaining])
            break
        lines.append(chunk)
        total += len(chunk) + 1

    digest = conn.execute(
        "SELECT summary_det, must_keep FROM digests WHERE session_id = ? AND turn_index = ?",
        (session_id, turn_index),
    ).fetchone()
    hint = ""
    if digest:
        hint = digest["summary_det"] or ""
    prompt = (
        "你是对话记忆整理器。阅读下面这一轮 agent 对话，输出严格的 JSON（不要 markdown 代码块）：\n"
        "{\n"
        '  "summary": "不超过 280 字：用户要什么、做了什么、最终结论是什么",\n'
        '  "decisions": ["这一轮做出的关键决定，0-5 条"],\n'
        '  "open_questions": ["尚未解决或待确认的问题，0-5 条"],\n'
        '  "must_keep": ["必须原样保留的精确信息：文件路径、命令、报错原文、URL、标题、版本号，0-12 条"]\n'
        "}\n"
        "要求：只写对话中出现的事实，不要猜测；保留中文原文的关键措辞；"
        "没有实质内容时 summary 写一句话即可。\n\n"
    )
    if hint:
        prompt += "已有确定性摘要（仅供参考，可修正）：\n" + hint[:2000] + "\n\n"
    prompt += "对话：\n" + "\n".join(lines)
    return prompt


def _parse_summary_json(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]

    def try_load(value: str):
        value = value.strip()
        try:
            return json.loads(value)
        except Exception:
            pass
        start = value.find("{")
        end = value.rfind("}")
        if start != -1 and end > start:
            try:
                return json.loads(value[start : end + 1])
            except Exception:
                pass
        return None

    obj = try_load(cleaned)
    # Some providers return a JSON string that itself contains the JSON object.
    if isinstance(obj, str):
        obj = try_load(obj)
    if not isinstance(obj, dict):
        return {"summary": text.strip(), "decisions": [], "open_questions": [], "must_keep": []}

    def as_list(value) -> list[str]:
        if isinstance(value, list):
            return [str(item).strip() for item in value if str(item).strip()]
        if isinstance(value, str) and value.strip():
            return [value.strip()]
        return []

    return {
        "summary": str(obj.get("summary") or "").strip() or text.strip(),
        "decisions": as_list(obj.get("decisions")),
        "open_questions": as_list(obj.get("open_questions")),
        "must_keep": as_list(obj.get("must_keep")),
    }


def _dedupe(items: list[str], limit: int = 32) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for item in items:
        item = item.strip()
        key = item.lower()
        if not item or key in seen:
            continue
        seen.add(key)
        out.append(item)
        if len(out) >= limit:
            break
    return out


def summarize_turn(
    conn,
    cfg: dict,
    session_id: str,
    turn_index: int,
    force: bool = False,
    model: str | None = None,
) -> dict:
    digest = conn.execute(
        "SELECT * FROM digests WHERE session_id = ? AND turn_index = ?",
        (session_id, turn_index),
    ).fetchone()
    if not digest:
        rebuild_digest(conn, session_id, turn_index)
        conn.commit()
        digest = conn.execute(
            "SELECT * FROM digests WHERE session_id = ? AND turn_index = ?",
            (session_id, turn_index),
        ).fetchone()
    if not digest:
        return {"session_id": session_id, "turn": turn_index, "skipped": "empty"}
    if digest["llm_updated_at"] and not force:
        return {"session_id": session_id, "turn": turn_index, "skipped": "already"}

    prompt = build_turn_payload(conn, session_id, turn_index)
    try:
        raw = call_llm(prompt, cfg, model=model)
    except Exception as exc:
        return {
            "session_id": session_id,
            "turn": turn_index,
            "skipped": f"llm_error: {exc}",
        }
    parsed = _parse_summary_json(raw)

    det_summary = digest["summary_det"] or digest["summary"] or ""
    det_must_keep = safe_json_loads(digest["must_keep"]) or []
    must_keep = _dedupe(list(parsed["must_keep"]) + list(det_must_keep))
    display = compose_summary(det_summary, parsed["summary"], must_keep)

    settings = api_settings(cfg, model=model)
    conn.execute(
        """
        UPDATE digests SET
            summary = ?, llm_summary = ?, decisions = ?, open_questions = ?,
            must_keep = ?, llm_model = ?, llm_updated_at = ?, updated_at = ?
        WHERE session_id = ? AND turn_index = ?
        """,
        (
            display,
            parsed["summary"],
            json_compact(parsed["decisions"]),
            json_compact(parsed["open_questions"]),
            json_compact(must_keep),
            settings["model"],
            now_iso(),
            now_iso(),
            session_id,
            turn_index,
        ),
    )
    conn.commit()
    return {
        "session_id": session_id,
        "turn": turn_index,
        "summary": parsed["summary"],
        "decisions": parsed["decisions"],
        "open_questions": parsed["open_questions"],
        "must_keep": must_keep,
    }


def summarize_many(
    conn,
    cfg: dict,
    limit: int = 50,
    force: bool = False,
    session: str | None = None,
    model: str | None = None,
    verbose: bool = True,
) -> dict:
    clause = "" if force else "AND (llm_updated_at IS NULL OR llm_updated_at = '')"
    params: list = []
    session_clause = ""
    if session:
        session_clause = "AND session_id LIKE ?"
        params.append(f"{session}%")
    rows = conn.execute(
        f"""
        SELECT session_id, turn_index FROM digests
        WHERE summary != '' {clause} {session_clause}
        ORDER BY COALESCE(ended_at, started_at) DESC
        LIMIT ?
        """,
        (*params, limit),
    ).fetchall()
    done = 0
    failed = 0
    errors: list[str] = []
    for index, row in enumerate(rows, 1):
        try:
            result = summarize_turn(
                conn,
                cfg,
                row["session_id"],
                int(row["turn_index"]),
                force=force,
                model=model,
            )
            if result.get("skipped"):
                if verbose and str(result["skipped"]).startswith("llm_error"):
                    print(f"[{index}/{len(rows)}] 跳过: {result['skipped']}")
                continue
            done += 1
            if verbose:
                print(
                    f"[{index}/{len(rows)}] {row['session_id'][:8]}#{row['turn_index']}: "
                    f"{clip(result['summary'], 100)}"
                )
        except Exception as exc:
            failed += 1
            errors.append(f"{row['session_id']}#{row['turn_index']}: {exc}")
            if verbose:
                print(f"[{index}/{len(rows)}] 失败: {exc}")
    return {"requested": len(rows), "done": done, "failed": failed, "errors": errors[:5]}


def spawn_auto_summary(cfg: dict, session_id: str, turn_index: int) -> bool:
    """Run one summary in a detached process so the Stop hook stays fast."""
    llm_cfg = cfg.get("llm") or {}
    if not llm_cfg.get("auto_summarize", True):
        return False
    if not api_settings(cfg)["enabled"]:
        return False
    if not session_id or turn_index <= 0:
        return False
    command = [
        sys.executable,
        str(ROOT / "mw.py"),
        "summarize",
        "--session",
        session_id,
        "--turn",
        str(turn_index),
        "--quiet",
    ]
    kwargs = {
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "cwd": str(ROOT),
    }
    if os.name == "nt":
        kwargs["creationflags"] = (
            getattr(subprocess, "CREATE_NO_WINDOW", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
        )
    try:
        subprocess.Popen(command, **kwargs)
        return True
    except Exception:
        return False
