#!/usr/bin/env python
"""One-shot installer for Memory Warehouse.

Checks the Python version and dependencies, optionally captures LLM
credentials from ANTHROPIC_* environment variables, installs the hooks and the
bundled skill. It never touches existing memory data.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import install_hooks  # noqa: E402
from warehouse.config import load_config  # noqa: E402


def check_python() -> bool:
    if sys.version_info < (3, 10):
        print(f"需要 Python 3.10+，当前是 {sys.version.split()[0]}")
        return False
    return True


def check_dependencies() -> bool:
    missing = []
    for module in ("numpy", "requests"):
        try:
            __import__(module)
        except ImportError:
            missing.append(module)
    if missing:
        print("缺少依赖：" + ", ".join(missing))
        print(f"请先运行：{sys.executable} -m pip install -r requirements.txt")
        return False
    try:
        __import__("fastembed")
    except ImportError:
        print("未安装 fastembed；向量检索会自动跳过，FTS / 摘要 / hooks 仍然可用。")
        print(f"  需要语义检索时运行：{sys.executable} -m pip install fastembed")
    return True


def capture_llm_env(force: bool = False, dry_run: bool = False) -> None:
    """Create llm.local.json from ANTHROPIC_* env vars if available."""
    target = ROOT / "llm.local.json"
    if target.exists() and not force:
        print(f"LLM 凭证已存在，跳过：{target}")
        return
    base_url = os.environ.get("ANTHROPIC_BASE_URL", "")
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    auth_token = os.environ.get("ANTHROPIC_AUTH_TOKEN", "")
    model = (
        os.environ.get("ANTHROPIC_DEFAULT_HAIKU_MODEL")
        or os.environ.get("ANTHROPIC_MODEL")
        or ""
    )
    if not (base_url and (api_key or auth_token)):
        print("未找到 ANTHROPIC_* 环境变量；LLM 摘要将保持关闭（FTS/向量/确定性摘要仍可用）。")
        return
    if dry_run:
        print(f"[dry-run] would write LLM credentials to {target}")
        return
    payload = {
        "enabled": True,
        "auto_summarize": True,
        "disable_thinking": True,
        "base_url": base_url,
        "api_key": api_key,
        "auth_token": auth_token,
        "model": model,
        "custom_headers": os.environ.get("ANTHROPIC_CUSTOM_HEADERS", ""),
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass
    print(f"已写入 LLM 凭证：{target}（请勿分享此文件）")


def check_model() -> None:
    cfg = load_config()
    path = Path(cfg["embeddings"].get("model_path") or "")
    if not path.is_absolute():
        path = ROOT / path
    if path.exists():
        print(f"向量模型：{path}")
    else:
        print(f"未找到向量模型：{path}")
        print(f"  运行 `{sys.executable} download_model.py` 下载，或直接使用纯 FTS 检索。")


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    parser = argparse.ArgumentParser(description="Install Memory Warehouse.")
    parser.add_argument("--settings", type=Path, help="settings.json path")
    parser.add_argument("--skills-dir", type=Path, help="skills directory")
    parser.add_argument("--no-hooks", action="store_true")
    parser.add_argument("--no-skill", action="store_true")
    parser.add_argument("--from-env", action="store_true", help="写 llm.local.json（覆盖已有）")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    if not check_python():
        return 1
    if not check_dependencies():
        return 1

    if args.from_env:
        capture_llm_env(force=True, dry_run=args.dry_run)
    else:
        capture_llm_env(force=False, dry_run=args.dry_run)

    code = 0
    if not args.no_hooks:
        code = install_hooks.install(args.settings, dry_run=args.dry_run)
    if code == 0 and not args.no_skill:
        code = install_hooks.install_skill(args.skills_dir, dry_run=args.dry_run)
    check_model()

    print("\n下一步：")
    print("  1. 完整重启 Cherry Studio / Claude Code，让 hooks 与 skill 生效")
    print(f'  2. 导入历史："{sys.executable}" mw.py sync')
    print(f'  3. 检索：    "{sys.executable}" mw.py recall "关键词"')
    print("  4. 查看状态：\"%s\" mw.py stats" % sys.executable)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
