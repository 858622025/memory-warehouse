#!/usr/bin/env python
"""Download the local embedding model used by Memory Warehouse.

Default: BAAI/bge-small-zh-v1.5 (512 dims, ~90MB ONNX), hosted at
Qdrant/bge-small-zh-v1.5 on Hugging Face.

Tries huggingface_hub first; falls back to direct HTTP through hf-mirror.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = "Qdrant/bge-small-zh-v1.5"
FILES = [
    "config.json",
    "model_optimized.onnx",
    "ort_config.json",
    "special_tokens_map.json",
    "tokenizer.json",
    "tokenizer_config.json",
    "vocab.txt",
]


def via_hub(dest: Path) -> bool:
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        return False
    try:
        snapshot_download(
            REPO,
            local_dir=str(dest),
            allow_patterns=FILES,
        )
        return True
    except Exception as exc:
        print(f"huggingface_hub 下载失败：{exc}")
        return False


def via_http(dest: Path, mirrors: list[str], verify: bool = True) -> bool:
    try:
        import requests
    except ImportError:
        print("缺少 requests，请先 pip install requests")
        return False
    dest.mkdir(parents=True, exist_ok=True)
    for filename in FILES:
        target = dest / filename
        if target.exists() and target.stat().st_size > 0:
            print(f"已存在：{filename}")
            continue
        last_error = None
        for mirror in mirrors:
            url = f"{mirror.rstrip('/')}/{REPO}/resolve/main/{filename}"
            print(f"下载 {filename} ← {mirror}")
            try:
                response = requests.get(url, timeout=120, verify=verify, stream=True)
                response.raise_for_status()
                tmp = target.with_suffix(target.suffix + ".part")
                with open(tmp, "wb") as handle:
                    for chunk in response.iter_content(chunk_size=1024 * 256):
                        if chunk:
                            handle.write(chunk)
                tmp.replace(target)
                last_error = None
                break
            except Exception as exc:
                last_error = exc
                print(f"  失败：{exc}")
        if last_error is not None:
            print(f"无法下载 {filename}：{last_error}")
            return False
    return True


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dest",
        type=Path,
        default=ROOT / "data" / "models" / "bge-small-zh-v1.5",
    )
    parser.add_argument(
        "--mirror",
        action="append",
        default=None,
        help="HF mirror base URL, repeatable",
    )
    parser.add_argument(
        "--insecure",
        action="store_true",
        help="disable TLS verification for mirrors with broken certificates",
    )
    args = parser.parse_args()
    dest = args.dest.resolve()
    mirrors = args.mirror or [
        "https://hf-mirror.com",
        "https://huggingface.co",
    ]

    print(f"模型目录：{dest}")
    if via_hub(dest):
        print("下载完成（huggingface_hub）")
        return 0
    if args.insecure:
        print("警告：已禁用 TLS 校验（--insecure）。请确认镜像可信。")
    if via_http(dest, mirrors, verify=not args.insecure):
        print("下载完成（HTTP）")
        return 0
    print("下载失败。可以手动从 Hugging Face 仓库 Qdrant/bge-small-zh-v1.5 下载上述文件。")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
