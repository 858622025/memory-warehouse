#!/usr/bin/env python
"""Launcher for the Memory Warehouse CLI.

Works from any cwd, which is important because hooks run with the agent's
project directory as their working directory.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

from warehouse.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
