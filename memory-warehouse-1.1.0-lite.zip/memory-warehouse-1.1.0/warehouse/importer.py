from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from pathlib import Path
from typing import Iterable

from .digest import rebuild_digest
from .textutil import now_iso
from .transcript import extract_events

INSERT_EVENT_SQL = """
INSERT OR IGNORE INTO events (
    event_key, session_id, turn_index, ts, role, kind, content, cwd,
    source, source_uuid, source_file, block_index, is_sidechain,
    pinned, tags, meta, created_at
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
"""

BATCH_SIZE = 400


def discover_transcripts(roots: Iterable[str], since_days: float | None = None) -> list[str]:
    import time

    cutoff = None
    if since_days is not None:
        cutoff = time.time() - since_days * 86400
    found: list[str] = []
    seen: set[str] = set()
    for root in roots:
        base = Path(root)
        if not base.exists():
            continue
        for path in base.rglob("*.jsonl"):
            try:
                real = str(path.resolve())
                if real in seen:
                    continue
                if cutoff is not None and path.stat().st_mtime < cutoff:
                    continue
                seen.add(real)
                found.append(real)
            except OSError:
                continue
    found.sort(key=lambda p: _safe_mtime(p))
    return found


def _safe_mtime(path: str) -> float:
    try:
        return os.stat(path).st_mtime
    except OSError:
        return 0.0


def _insert_events(conn: sqlite3.Connection, events: list[dict]) -> int:
    if not events:
        return 0
    before = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    created = now_iso()
    rows = [
        (
            ev["event_key"],
            ev.get("session_id"),
            ev.get("turn_index", 0),
            ev.get("ts"),
            ev.get("role"),
            ev.get("kind"),
            ev.get("content") or "",
            ev.get("cwd"),
            ev.get("source"),
            ev.get("source_uuid"),
            ev.get("source_file"),
            ev.get("block_index"),
            ev.get("is_sidechain", 0),
            ev.get("pinned", 0),
            ev.get("tags"),
            ev.get("meta"),
            created,
        )
        for ev in events
    ]
    conn.executemany(INSERT_EVENT_SQL, rows)
    after = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    return after - before


def sync_transcript(
    conn: sqlite3.Connection,
    path: str,
    cfg: dict,
    verbose: bool = False,
) -> dict:
    """Incrementally import one append-only transcript JSONL file."""
    path = os.path.abspath(path)
    try:
        stat = os.stat(path)
    except OSError as exc:
        return {"path": path, "error": str(exc), "imported": 0}

    row = conn.execute("SELECT * FROM import_state WHERE path = ?", (path,)).fetchone()
    offset = int(row["offset"]) if row else 0
    turn_counter = int(row["turn_counter"]) if row else 0
    line_no = int(row["line_no"]) if row else 0
    session_id = row["session_id"] if row else None

    if offset > stat.st_size:
        # File was truncated or replaced: start over. event_key dedupe protects us.
        offset = 0
        turn_counter = 0
        line_no = 0

    ctx = {
        "cfg": cfg,
        "session_id": session_id,
        "turn_counter": turn_counter,
        "source_file": path,
        "line_hash": "",
    }

    extracted = 0
    imported = 0
    parsed_lines = 0
    skipped_lines = 0
    touched: set[tuple[str | None, int]] = set()
    pending: list[dict] = []
    boundary_drops: list[tuple[str, list[tuple[str, int]]]] = []
    new_offset = offset

    try:
        handle = open(path, "rb")
    except OSError as exc:
        return {"path": path, "error": str(exc), "imported": 0}

    with handle:
        handle.seek(offset)
        while True:
            line = handle.readline()
            if not line:
                break
            if not line.endswith(b"\n"):
                # Partial write at the tail; leave it for the next sync.
                break
            new_offset = handle.tell()
            line_no += 1
            stripped = line.strip()
            if not stripped:
                continue
            parsed_lines += 1
            ctx["line_hash"] = hashlib.sha1(stripped).hexdigest()[:16]
            try:
                rec = json.loads(stripped.decode("utf-8", errors="replace"))
            except Exception:
                skipped_lines += 1
                continue
            if not isinstance(rec, dict):
                skipped_lines += 1
                continue

            try:
                events = extract_events(rec, ctx)
            except Exception:
                skipped_lines += 1
                continue
            for event in events:
                drops = event.pop("drops", None)
                pending.append(event)
                extracted += 1
                if event.get("session_id") is not None:
                    touched.add((event.get("session_id"), int(event.get("turn_index") or 0)))
                if drops:
                    boundary_drops.append((event["event_key"], drops))

            if len(pending) >= BATCH_SIZE:
                imported += _insert_events(conn, pending)
                conn.commit()
                pending.clear()

    imported += _insert_events(conn, pending)
    pending.clear()

    # Record exactly which context messages each compaction removed.
    for event_key, drops in boundary_drops:
        found = conn.execute("SELECT id FROM events WHERE event_key = ?", (event_key,)).fetchone()
        if not found:
            continue
        event_id = int(found["id"])
        conn.executemany(
            "INSERT OR IGNORE INTO compaction_drops(event_id, uuid, preserved) VALUES (?, ?, ?)",
            [(event_id, uuid, preserved) for uuid, preserved in drops],
        )

    # Refresh deterministic turn digests for everything we just touched.
    digest_count = 0
    for sid, turn in touched:
        if sid and turn > 0:
            if rebuild_digest(conn, sid, turn) is not None:
                digest_count += 1

    conn.execute(
        """
        INSERT INTO import_state(path, size, mtime, offset, line_no, turn_counter, session_id, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(path) DO UPDATE SET
            size=excluded.size, mtime=excluded.mtime, offset=excluded.offset,
            line_no=excluded.line_no, turn_counter=excluded.turn_counter,
            session_id=excluded.session_id, updated_at=excluded.updated_at
        """,
        (
            path,
            stat.st_size,
            stat.st_mtime,
            new_offset,
            line_no,
            ctx["turn_counter"],
            ctx.get("session_id"),
            now_iso(),
        ),
    )
    conn.commit()

    result = {
        "path": path,
        "session_id": ctx.get("session_id"),
        "imported": imported,
        "extracted": extracted,
        "parsed_lines": parsed_lines,
        "skipped_lines": skipped_lines,
        "digests": digest_count,
        "offset": new_offset,
        "bytes": stat.st_size,
    }
    if verbose:
        print(f"  {Path(path).name}: +{imported} events, {digest_count} digests")
    return result


def sync_all(
    conn: sqlite3.Connection,
    cfg: dict,
    roots: list[str] | None = None,
    since_days: float | None = None,
    verbose: bool = True,
) -> dict:
    paths = discover_transcripts(roots or cfg.get("transcript_roots") or [], since_days)
    total_events = 0
    errors: list[str] = []
    if verbose:
        print(f"发现 {len(paths)} 个 transcript 文件")
    for index, path in enumerate(paths, 1):
        if verbose:
            print(f"[{index}/{len(paths)}] {Path(path).name}")
        result = sync_transcript(conn, path, cfg, verbose=False)
        if result.get("error"):
            errors.append(f"{path}: {result['error']}")
        else:
            total_events += int(result.get("imported") or 0)
    return {"files": len(paths), "events": total_events, "errors": errors}
