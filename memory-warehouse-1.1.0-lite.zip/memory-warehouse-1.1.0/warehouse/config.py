from __future__ import annotations

import copy
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.json"

DEFAULTS = {
    "db_path": "data/memory.db",
    "transcript_roots": [],
    "caps": {
        "prompt": 4000,
        "text": 6000,
        "thinking": 2000,
        "tool_use": 4000,
        "tool_result": 3000,
        "compaction_summary": 12000,
        "compact_boundary": 2000,
        "system": 2000,
        "image": 200,
        "checkpoint": 8000,
        "note": 8000,
    },
    "redact": True,
    "brief_max_chars": 3500,
    "brief_recent_digests": 6,
    "brief_checkpoints": 2,
    "llm": {
        "enabled": True,
        "auto_summarize": True,
        "disable_thinking": True,
        "timeout": 60,
        "max_tokens": 2500,
    },
    "embeddings": {
        "enabled": True,
        "auto": True,
        "auto_build": True,
        "model": "BAAI/bge-small-zh-v1.5",
        "model_path": "data/models/bge-small-zh-v1.5",
        "batch_size": 32,
        "max_events": 20000,
        "min_score": 0.28,
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def _default_roots() -> list[str]:
    roots: list[str] = []
    appdata = os.environ.get("APPDATA")
    if appdata:
        roots.append(str(Path(appdata) / "CherryStudio" / "Data" / "Agents" / ".claude" / "projects"))
    home = Path.home()
    roots.append(str(home / ".claude" / "projects"))
    return roots


def _abspath(value: str) -> str:
    p = Path(os.path.expandvars(os.path.expanduser(value)))
    if not p.is_absolute():
        p = ROOT / p
    return str(p.resolve())


def load_config(path: str | os.PathLike | None = None) -> dict:
    cfg = copy.deepcopy(DEFAULTS)
    cfg["transcript_roots"] = _default_roots()
    cfg_path = Path(path) if path else Path(
        os.environ.get("MEMORY_WAREHOUSE_CONFIG") or CONFIG_PATH
    )
    if cfg_path.exists():
        try:
            cfg = _deep_merge(cfg, json.loads(cfg_path.read_text(encoding="utf-8")))
        except Exception:
            # A broken config must never stop a hook from running.
            pass
    # Credentials live outside config.json so the project file stays shareable.
    local_path = cfg_path.parent / "llm.local.json"
    if local_path.exists():
        try:
            local_llm = json.loads(local_path.read_text(encoding="utf-8"))
            if isinstance(local_llm, dict):
                cfg["llm"] = _deep_merge(cfg.get("llm") or {}, local_llm)
        except Exception:
            pass

    env_db = os.environ.get("MEMORY_WAREHOUSE_DB")
    cfg["db_path"] = _abspath(env_db or cfg.get("db_path") or "data/memory.db")
    cfg["transcript_roots"] = [
        _abspath(r) for r in (cfg.get("transcript_roots") or []) if r
    ]
    # de-dupe while preserving order
    seen: set[str] = set()
    roots = []
    for r in cfg["transcript_roots"]:
        if r.lower() not in seen:
            seen.add(r.lower())
            roots.append(r)
    cfg["transcript_roots"] = roots
    return cfg


def caps_for(cfg: dict) -> dict:
    return cfg.get("caps") or DEFAULTS["caps"]
