from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

from .brief import build_brief
from .config import ROOT, load_config
from .db import connect, db_stats, rebuild_fts
from .digest import rebuild_all, rebuild_digest
from .hooks import create_checkpoint_from_tail
from .importer import sync_all, sync_transcript
from .llm import llm_status, summarize_many, summarize_turn
from .vectors import build_vectors, vector_stats
from .search import (
    format_results,
    lost_events,
    search,
    show_event,
    timeline,
)
from .textutil import (
    cap_text,
    clip,
    json_compact,
    normalize_cwd,
    now_iso,
    parse_since,
    project_label,
    safe_json_loads,
)


def _split_csv(values: list[str] | None) -> list[str]:
    out: list[str] = []
    for value in values or []:
        for part in str(value).split(","):
            part = part.strip()
            if part and part not in out:
                out.append(part)
    return out


def _add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--cwd", help="只查某个工作目录 (大小写不敏感)")
    parser.add_argument("--session", help="session id 前缀")
    parser.add_argument("--since", help="起始时间：7d / 24h / 2026-10-01")
    parser.add_argument("--until", help="结束时间")
    parser.add_argument("--limit", "-n", type=int, default=10)
    parser.add_argument("--json", action="store_true", help="输出 JSON")


def cmd_init(args, cfg, conn):
    print(f"数据库: {cfg['db_path']}")
    print(json.dumps(db_stats(conn), ensure_ascii=False, indent=2))
    return 0


def cmd_sync(args, cfg, conn):
    if args.rebuild_digests:
        count = rebuild_all(conn, limit=args.limit or None)
        print(f"重建 {count} 个回合摘要")
        return 0
    since_days = args.since_days
    if args.transcript:
        for path in args.transcript:
            result = sync_transcript(conn, path, cfg, verbose=not args.quiet)
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            elif not args.quiet:
                print(
                    f"  {Path(path).name}: +{result.get('imported', 0)} events, "
                    f"{result.get('digests', 0)} digests"
                )
        return 0
    roots = args.root or cfg.get("transcript_roots") or []
    result = sync_all(conn, cfg, roots=roots, since_days=since_days, verbose=not args.quiet)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"完成：{result['files']} 个文件，新增 {result['events']} 条事件")
        for error in result["errors"]:
            print(f"  错误: {error}")
    return 0


def cmd_recall(args, cfg, conn):
    query = " ".join(args.query)
    semantic = None
    if getattr(args, "semantic", False):
        semantic = True
    elif getattr(args, "no_semantic", False):
        semantic = False
    results = search(
        conn,
        query,
        cfg=cfg,
        semantic=semantic,
        limit=args.limit,
        cwd=args.cwd,
        session=args.session,
        kinds=_split_csv(args.kind) or None,
        since=parse_since(args.since),
        until=parse_since(args.until),
        include_sidechain=args.include_sidechain,
        any_terms=args.any,
    )
    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return 0
    print(format_results(results, show_scores=args.scores or getattr(args, "explain", False)))
    if args.full:
        for item in results:
            if item["type"] != "event":
                continue
            print("\n" + "=" * 70)
            record = show_event(conn, int(item["id"]))
            print(f"id={record['id']} {record['ts']} {record['kind']} {record['cwd']}")
            print(record["full_content"])
    return 0


def cmd_show(args, cfg, conn):
    try:
        record = show_event(conn, args.id)
    except KeyError as exc:
        print(str(exc))
        return 1
    if args.json:
        print(json.dumps(record, ensure_ascii=False, indent=2))
        return 0
    print(f"id={record['id']}  {record['ts']}  {record['kind']}  {record['cwd']}")
    print(f"session={record['session_id']}  turn={record['turn_index']}")
    if record.get("source_file"):
        print(f"source={record['source_file']}#{record.get('source_uuid')}")
    print("-" * 70)
    print(record["full_content"])
    return 0


def cmd_brief(args, cfg, conn):
    text = build_brief(
        conn,
        cfg,
        cwd=args.cwd,
        source=args.source,
        max_chars=args.max_chars,
    )
    if args.json:
        print(json.dumps({"brief": text}, ensure_ascii=False, indent=2))
    else:
        print(text)
    return 0


def _insert_manual_event(
    conn,
    cfg,
    *,
    kind: str,
    text: str,
    cwd: str | None,
    pinned: bool,
    tags: list[str],
    meta: dict | None = None,
) -> int:
    caps = cfg.get("caps") or {}
    content, truncated, original_len = cap_text(text, int(caps.get(kind, 8000)))
    stamp = now_iso()
    digest = hashlib.sha1(f"{kind}:{stamp}:{text}".encode("utf-8")).hexdigest()[:12]
    event_key = f"{kind}:{stamp}:{digest}"
    meta = dict(meta or {})
    meta.update({"manual": True, "truncated": truncated, "original_len": original_len})
    conn.execute(
        """
        INSERT OR IGNORE INTO events (
            event_key, session_id, turn_index, ts, role, kind, content, cwd,
            source, source_uuid, source_file, block_index, is_sidechain,
            pinned, tags, meta, created_at
        ) VALUES (?, 'manual', 0, ?, 'agent', ?, ?, ?, 'manual', NULL, NULL, 0, 0, ?, ?, ?, ?)
        """,
        (
            event_key,
            stamp,
            kind,
            content,
            normalize_cwd(cwd) or normalize_cwd(os.getcwd()),
            1 if pinned else 0,
            json_compact(tags),
            json_compact(meta),
            stamp,
        ),
    )
    conn.commit()
    row = conn.execute("SELECT id FROM events WHERE event_key = ?", (event_key,)).fetchone()
    return int(row["id"]) if row else 0


def cmd_remember(args, cfg, conn):
    text = " ".join(args.text)
    tags = _split_csv(args.tags)
    event_id = _insert_manual_event(
        conn,
        cfg,
        kind="note",
        text=text,
        cwd=args.cwd,
        pinned=args.pinned,
        tags=tags,
    )
    print(f"已记录 note id={event_id}" + ("（固定记忆）" if args.pinned else ""))
    return 0


def cmd_checkpoint(args, cfg, conn):
    if args.from_tail:
        checkpoint_id = create_checkpoint_from_tail(
            conn,
            cfg,
            session_id=args.from_tail,
            cwd=args.cwd,
            trigger=args.trigger,
            pre_tokens=args.pre_tokens,
        )
        print(f"已生成检查点 id={checkpoint_id}")
        return 0
    if not args.summary:
        print("需要 --summary 或 --from-tail <session>")
        return 1
    text = " ".join(args.summary)
    must_keep = _split_csv(args.must_keep)
    if must_keep:
        text += "\n关键标识：" + "; ".join(must_keep)
    event_id = _insert_manual_event(
        conn,
        cfg,
        kind="checkpoint",
        text=text,
        cwd=args.cwd,
        pinned=args.pinned,
        tags=["checkpoint", args.trigger],
        meta={"trigger": args.trigger, "must_keep": must_keep},
    )
    print(f"已记录 checkpoint id={event_id}")
    return 0


def cmd_timeline(args, cfg, conn):
    rows = timeline(
        conn,
        cwd=args.cwd,
        session=args.session,
        limit=args.limit,
    )
    if args.json:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0
    if not rows:
        print("没有回合摘要。先运行 `mw.py sync`。")
        return 0
    for row in reversed(rows):
        ts = (row.get("ended_at") or row.get("started_at") or "")[:16].replace("T", " ")
        print(f"{ts} · {project_label(row.get('cwd'))} · {row['session_id'][:8]}#{row['turn_index']}")
        summary = " · ".join((row.get("summary") or "").splitlines())
        print("  " + clip(summary, 300))
    return 0


def cmd_lost(args, cfg, conn):
    rows = lost_events(conn, args.session, limit=args.limit)
    if args.json:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0
    if not rows:
        print("没有记录到被压缩掉的事件（可能需要先 sync 含 compact_boundary 的 transcript）。")
        return 0
    for row in rows:
        ts = (row.get("ts") or "")[:16].replace("T", " ")
        print(f"[{row['id']}] {ts} {row['role']}/{row['kind']} #{row['turn_index']}")
        print("  " + clip(row.get("content") or "", 260))
    return 0


def cmd_stats(args, cfg, conn):
    stats = db_stats(conn)
    stats["db_path"] = cfg["db_path"]
    stats["last_import"] = (
        conn.execute("SELECT MAX(updated_at) FROM import_state").fetchone()[0]
    )
    stats["transcripts"] = conn.execute("SELECT COUNT(*) FROM import_state").fetchone()[0]
    stats["llm"] = llm_status(cfg)
    stats["vector_index"] = vector_stats(conn)
    if args.json:
        print(json.dumps(stats, ensure_ascii=False, indent=2))
    else:
        print(f"数据库: {stats['db_path']} ({stats['db_bytes'] / 1024 / 1024:.1f} MB)")
        print(f"事件: {stats['events']:,}   回合: {stats['turns']:,}   会话: {stats['sessions']:,}")
        print(
            f"笔记: {stats['notes']}   检查点: {stats['checkpoints']}   "
            f"压缩次数: {stats['compactions']}"
        )
        print(f"LLM 摘要: {stats['llm_summaries']:,} 条")
        vector_index = stats["vector_index"]
        print(
            f"向量: {vector_index['total']:,} 条目标 / "
            f"{vector_index.get('chunks', 0):,} 个块 "
            f"(事件 {vector_index['events']:,} / 摘要 {vector_index['digests']:,})"
        )
        print(f"时间范围: {stats['first_ts']} → {stats['last_ts']}")
        print(f"已索引 transcript: {stats['transcripts']}   最近导入: {stats['last_import']}")
        llm = stats["llm"]
        print(
            f"LLM: {'启用' if llm['enabled'] else '未配置'} · {llm['model']} · "
            f"{llm['endpoint']}"
        )
    return 0


def cmd_embed(args, cfg, conn):
    result = build_vectors(
        conn,
        cfg,
        force=args.force,
        limit=args.limit or None,
        verbose=not args.quiet,
    )
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_summarize(args, cfg, conn):
    if args.session and args.turn is not None:
        session = args.session
        row = conn.execute(
            "SELECT session_id FROM digests WHERE session_id LIKE ? ORDER BY id DESC LIMIT 1",
            (f"{session}%",),
        ).fetchone()
        if row:
            session = row["session_id"]
        result = summarize_turn(
            conn,
            cfg,
            session,
            args.turn,
            force=args.force,
            model=args.model,
        )
        if not args.quiet:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    result = summarize_many(
        conn,
        cfg,
        limit=args.limit,
        force=args.force,
        session=args.session,
        model=args.model,
        verbose=not args.quiet,
    )
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_digest(args, cfg, conn):
    if args.session and args.turn is not None:
        digest_id = rebuild_digest(conn, args.session, args.turn)
        conn.commit()
        print(f"digest id={digest_id}")
        return 0
    count = rebuild_all(conn, limit=args.limit or None)
    print(f"重建 {count} 个回合摘要")
    return 0


def cmd_export(args, cfg, conn):
    rows = timeline(conn, cwd=args.cwd, session=args.session, limit=args.limit)
    notes = [
        dict(row)
        for row in conn.execute(
            """
            SELECT id, ts, cwd, kind, content, tags FROM events
            WHERE kind IN ('note', 'checkpoint')
            ORDER BY id DESC LIMIT ?
            """,
            (args.limit,),
        ).fetchall()
    ]
    if args.format == "json":
        payload = {
            "generated_at": now_iso(),
            "digests": [dict(row) for row in rows],
            "notes": [dict(row) for row in notes],
        }
        text = json.dumps(payload, ensure_ascii=False, indent=2)
    else:
        lines = [f"# Memory Warehouse 导出", f"生成时间：{now_iso()}", ""]
        lines.append("## 时间线")
        for row in reversed(rows):
            ts = (row.get("ended_at") or row.get("started_at") or "")[:16].replace("T", " ")
            lines.append(
                f"### {ts} · {project_label(row.get('cwd'))} · "
                f"{row['session_id'][:8]}#{row['turn_index']}"
            )
            lines.append(row.get("summary") or "")
            lines.append("")
        if notes:
            lines.append("## 笔记 / 检查点")
            for row in reversed(notes):
                ts = (row.get("ts") or "")[:16].replace("T", " ")
                lines.append(f"### [{row['kind']}] {ts} · {project_label(row.get('cwd'))}")
                lines.append(row.get("content") or "")
                lines.append("")
        text = "\n".join(lines)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"已导出到 {args.out}")
    else:
        print(text)
    return 0


def cmd_import_journal(args, cfg, conn):
    paths: list[Path] = []
    if args.path:
        paths = [Path(p) for p in args.path]
    else:
        appdata = Path(
            os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))
        )
        paths = sorted(
            (appdata / "CherryStudio" / "Data" / "Agents").glob("*/memory/JOURNAL.jsonl")
        )
    imported = 0
    for path in paths:
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
            except Exception:
                continue
            text = str(item.get("text") or "").strip()
            if not text:
                continue
            tags = item.get("tags") or []
            stamp = str(item.get("ts") or now_iso())
            digest = hashlib.sha1(f"{path}:{line}".encode("utf-8")).hexdigest()[:16]
            event_key = f"journal:{digest}"
            content, truncated, original_len = cap_text(
                text, int((cfg.get("caps") or {}).get("note", 8000))
            )
            meta = {
                "journal_file": str(path),
                "source_ts": stamp,
                "truncated": truncated,
                "original_len": original_len,
            }
            before = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            conn.execute(
                """
                INSERT OR IGNORE INTO events (
                    event_key, session_id, turn_index, ts, role, kind, content, cwd,
                    source, source_uuid, source_file, block_index, is_sidechain,
                    pinned, tags, meta, created_at
                ) VALUES (?, 'journal', 0, ?, 'agent', 'note', ?, NULL,
                          'journal', NULL, ?, 0, 0, 0, ?, ?, ?)
                """,
                (
                    event_key,
                    stamp,
                    content,
                    str(path),
                    json_compact(tags),
                    json_compact(meta),
                    now_iso(),
                ),
            )
            after = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            imported += after - before
    conn.commit()
    print(f"从 {len(paths)} 个 JOURNAL.jsonl 导入 {imported} 条笔记" + ("" if imported else "（无新增）"))
    return 0


def cmd_rebuild_fts(args, cfg, conn):
    rebuild_fts(conn)
    print("FTS 索引已重建")
    return 0


def cmd_vacuum(args, cfg, conn):
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.execute("VACUUM")
    conn.commit()
    print("VACUUM 完成")
    return 0


def cmd_hook(args, cfg, conn):
    # run_hook opens its own connection; this one is unused.
    from .hooks import run_hook

    return run_hook(args.name)


def cmd_mcp(args, cfg, conn):
    from .mcp_server import serve

    return serve(cfg)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mw",
        description="本地对话记忆仓库：SQLite + FTS5，支持上下文压缩后的记忆找回。",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="初始化数据库")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("sync", help="导入 transcript（增量）")
    p.add_argument("--transcript", action="append", help="指定 transcript 文件，可重复")
    p.add_argument("--root", action="append", help="指定 transcript 根目录，可重复")
    p.add_argument("--since-days", type=float, help="只导入最近 N 天修改的文件")
    p.add_argument("--rebuild-digests", action="store_true", help="只重建回合摘要")
    p.add_argument("--limit", type=int, default=0, help="配合 --rebuild-digests 限制数量")
    p.add_argument("--quiet", "-q", action="store_true")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_sync)

    p = sub.add_parser("recall", help="全文检索记忆")
    p.add_argument("query", nargs="+")
    _add_common(p)
    p.add_argument("--kind", action="append", help="限定 kind，可重复/逗号分隔；digest 表示摘要")
    p.add_argument("--include-sidechain", action="store_true", help="包含子代理事件")
    p.add_argument("--any", action="store_true", help="任一词命中即可")
    p.add_argument("--scores", action="store_true", help="显示排序分数")
    p.add_argument("--explain", action="store_true", help="显示 BM25/向量排名来源")
    p.add_argument("--semantic", action="store_true", help="强制启用向量检索")
    p.add_argument("--no-semantic", action="store_true", help="禁用向量检索，只走 FTS")
    p.add_argument("--full", action="store_true", help="同时打印完整内容")
    p.set_defaults(func=cmd_recall)

    p = sub.add_parser("show", help="显示某条事件的完整内容")
    p.add_argument("id", type=int)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_show)

    p = sub.add_parser("brief", help="打印会话启动用的记忆摘要")
    p.add_argument("--cwd")
    p.add_argument("--source", help="SessionStart 的 source: startup/resume/clear/compact")
    p.add_argument("--max-chars", type=int)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_brief)

    p = sub.add_parser("remember", help="写入一条固定记忆/笔记")
    p.add_argument("text", nargs="+")
    p.add_argument("--tags", action="append")
    p.add_argument("--pinned", action="store_true")
    p.add_argument("--cwd")
    p.set_defaults(func=cmd_remember)

    p = sub.add_parser("checkpoint", help="写入检查点（压缩前快照）")
    p.add_argument("--summary", nargs="+")
    p.add_argument("--must-keep", action="append", help="关键标识，可重复/逗号分隔")
    p.add_argument("--from-tail", metavar="SESSION", help="从该会话最近事件自动生成")
    p.add_argument("--trigger", default="manual")
    p.add_argument("--pre-tokens", type=int)
    p.add_argument("--cwd")
    p.add_argument("--pinned", action="store_true")
    p.set_defaults(func=cmd_checkpoint)

    p = sub.add_parser("timeline", help="查看回合摘要时间线")
    p.add_argument("--cwd")
    p.add_argument("--session")
    p.add_argument("--limit", "-n", type=int, default=30)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_timeline)

    p = sub.add_parser("lost", help="查看某会话中被压缩掉的事件")
    p.add_argument("--session", required=True)
    p.add_argument("--limit", "-n", type=int, default=100)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_lost)

    p = sub.add_parser("stats", help="数据库统计")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_stats)

    p = sub.add_parser("digest", help="重建回合摘要")
    p.add_argument("--session")
    p.add_argument("--turn", type=int)
    p.add_argument("--limit", type=int, default=0)
    p.set_defaults(func=cmd_digest)

    p = sub.add_parser("export", help="导出时间线")
    p.add_argument("--format", choices=["md", "json"], default="md")
    p.add_argument("--out")
    p.add_argument("--cwd")
    p.add_argument("--session")
    p.add_argument("--limit", "-n", type=int, default=200)
    p.set_defaults(func=cmd_export)

    p = sub.add_parser("embed", help="构建/更新本地向量索引")
    p.add_argument("--force", action="store_true", help="全量重算")
    p.add_argument("--limit", type=int, default=0, help="最多处理 N 条")
    p.add_argument("--quiet", "-q", action="store_true")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_embed)

    p = sub.add_parser("summarize", help="用 LLM 生成语义回合摘要")
    p.add_argument("--session")
    p.add_argument("--turn", type=int)
    p.add_argument("--limit", type=int, default=20, help="最多处理 N 个最新回合")
    p.add_argument("--force", action="store_true", help="覆盖已有 LLM 摘要")
    p.add_argument("--model", help="覆盖模型名")
    p.add_argument("--quiet", "-q", action="store_true")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_summarize)

    p = sub.add_parser("import-journal", help="导入 agent 的 JOURNAL.jsonl 笔记")
    p.add_argument("--path", action="append", help="指定 JOURNAL.jsonl，可重复")
    p.set_defaults(func=cmd_import_journal)

    p = sub.add_parser("rebuild-fts", help="重建 FTS 索引")
    p.set_defaults(func=cmd_rebuild_fts)

    p = sub.add_parser("vacuum", help="压缩数据库")
    p.set_defaults(func=cmd_vacuum)

    p = sub.add_parser("hook", help="hook 入口（供 settings.json 调用）")
    p.add_argument("name", choices=["session-start", "stop", "pre-compact", "session-end"])
    p.set_defaults(func=cmd_hook)

    p = sub.add_parser("mcp", help="以 MCP stdio server 运行")
    p.set_defaults(func=cmd_mcp)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    cfg = load_config()

    if args.command == "hook":
        return args.func(args, cfg, None)

    conn = connect(cfg["db_path"])
    try:
        return args.func(args, cfg, conn)
    finally:
        conn.close()
