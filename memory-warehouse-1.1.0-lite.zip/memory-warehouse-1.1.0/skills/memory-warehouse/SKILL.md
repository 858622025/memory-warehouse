---
name: memory-warehouse
description: 本地对话记忆仓库。当用户提到"上次/之前/还记得吗/我们聊过"、需要跨会话回忆、或上下文压缩后丢失了细节时，用它检索 SQLite 历史索引（BM25 + 本地向量混合检索，含 LLM 语义摘要）；也用于写入固定记忆和压缩前检查点。
---

# Memory Warehouse（本地记忆仓库）

历史对话、工具调用、命令、文件和每轮摘要都已经索引在本机 SQLite 里。SessionStart 会自动注入一份最近摘要；更早的细节用本技能现场检索。

## 优先级

1. 如果本会话暴露了 `memory-warehouse` 的 MCP 工具（`recall` / `remember` / `checkpoint` / `brief` / `stats` / `summarize` / `embed`），优先直接调用。`summarize` / `embed` 可能需要新会话重载工具列表后才出现。
2. 否则走 CLI（任何工作目录都可用）：

```bash
python "{{MW_ROOT}}/mw.py" recall "关键词1 关键词2" -n 8
```

## 检索

```bash
# 基本检索；BM25 + 本地向量自动融合，中文按三元组匹配
mw recall "DPI 缩放" -n 8
mw recall "上下文丢了怎么恢复" --explain
mw recall "黄金裔 卡组" --since 90d
mw recall "bubbleMode hover" --kind text

# 只看摘要 / 笔记 / 检查点
mw recall "关键词" --kind digest
mw recall "关键词" --kind note,checkpoint

# 排查排序 / 强制只走 FTS / 强制语义
mw recall "关键词" --explain
mw recall "关键词" --no-semantic
mw recall "关键词" --semantic

# 查看某条事件的完整原文（入库时会截断，show 从原 transcript 回取）
mw show 12345

# 时间线 / 统计 / 某会话被压缩掉的内容
mw timeline -n 20
mw stats
mw lost --session 78a8f3fe

# 语义摘要与向量索引（Stop 后也会自动增量跑）
mw summarize --limit 20
mw embed
```

其中 `mw` 指：

```bash
python "{{MW_ROOT}}/mw.py"
```

## V2 / V3 能力

- **默认混合检索**：BM25 + 本地向量（`bge-small-zh`，按标点切成 60–120 字的块）用 RRF 融合。精确关键词 / 代码符号优先 `--no-semantic`；只记得大意、换了说法时用默认或 `--semantic`。
- **`--explain`**：显示 `bm#` / `vec#` / 余弦分数，用来判断是关键词命中还是语义命中。
- **LLM 回合摘要**：每轮由 Stop hook 异步生成，包含 `summary` / `decisions` / `open_questions` / `must_keep`。历史回合并未被覆盖时，用 `mw summarize --limit N` 补。
- **向量索引**：Stop 后自动增量；手动 `mw embed`。模型目录缺失时会自动退回纯 FTS，不会报错。
- `mw stats` 能看到 LLM 摘要数、向量目标数 / 块数，以及当前 LLM 是否可用。

**什么时候用哪个**

| 场景 | 用法 |
|---|---|
| 记得原话、文件名、命令、符号 | 默认检索即可；`--explain` 看命中来源 |
| 只记得大意，原话对不上 | 默认（语义）或 `--semantic` |
| 排查为什么没搜到 / 只要字面匹配 | `--no-semantic` 对比 |
| 想要更完整的结论和决策 | `--kind digest`，或 `show <id>` 看摘要 |
| 需要补历史摘要 / 向量 | `mw summarize --limit N` / `mw embed` |

## 写入

用户明确说"记住"，或你发现一条跨会话仍然成立的事实时：

```bash
mw remember "事实内容" --pinned --tags 项目名
```

`--pinned` 会进入每次会话的自动摘要，只放真正长期有效的内容。

压缩前抢救进度：

```bash
mw checkpoint --summary "当前进度、已完成、未完成" --must-keep "关键路径, 命令, 报错原文"
```

## 使用原则

- 不要一次把大量历史倒进上下文。先 `recall` 拿片段，需要时再 `show` 单条。
- 检索不到时：换更短的关键词、去掉太具体的短语、加 `--since 90d`，或改用 `--any`；也可以 `--no-semantic` 和默认各跑一次，看是关键词问题还是语义模型没覆盖。
- 仓库只覆盖安装之后新产生的压缩。安装前已经被压缩掉的内容无法恢复；不要声称"记得"不存在的东西。
- 回答用户关于过去的细节时，尽量引用 `recall` 结果里的时间、会话和 `id`，方便继续 `show`。
