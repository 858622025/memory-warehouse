"""Local conversation memory warehouse.

Indexes agent session transcripts into SQLite + FTS5 so details lost to
context compaction can be recalled later.
"""

__version__ = "1.3.0"
